function K = kernel(x1,x2,k_type,k_par)

switch k_type
    case 'rbf'
        K = rbf_kern(x1,x2,k_par);
    case 'linear'
        K = x1*x2';
 case 'polynomial'
        K = (x1*x2'+1).^k_par;
end