function K = rbf_kern(x1,x2,par)
%evaluates rbf kernel at points in x1 and x2 with parameters in par
no1 = size(x1,1);
no2 = size(x2,1);   

K = zeros(no1,no2);
for i = 1:no1
    for j = 1:no2
        K(i,j) = exp(-(1/(2*par^2))*(x1(i,:)-x2(j,:))*(x1(i,:)-x2(j,:))');
    end
end