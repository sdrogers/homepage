%Heterogenous Kernel Combination
%Variational Bayes Regression Test Script
clear all
fprintf('\n\nHeterogenous Kernel Combination - Variational Bayes Classification Script');
fprintf('\nSimon Rogers & Mark Girolami, March 2004');
fprintf('\n****************************************');

%create data
fprintf('\nCreating Data...');
NoS = 100;
x = randn(NoS,2);
x((NoS/2)+1:end,:) = x((NoS/2)+1:end,:) + repmat(3,NoS/2,2);
t = [repmat(1,NoS/2,1); repmat(-1,NoS/2,1)];
figure(1);
hold off;
plot(x(find(t==1),1),x(find(t==1),2),'r.');
hold on;
plot(x(find(t==-1),1),x(find(t==-1),2),'b.');
drawnow;

%Define kernel types and parameters
fprintf('\nDefining Kernels...');
Kdef(1).ktype = 'rbf';
Kdef(1).kpar = 1;
Kdef(2).ktype = 'polynomial';
Kdef(2).kpar = 3;
Kdef(3).ktype = 'linear';
Kdef(3).kpar = 1;

txr = [-3:0.3:6]';
Notx = length(txr);
testx = [repmat(txr,Notx,1) reshape(repmat(txr',Notx,1),Notx^2,1)];

%Making kernels
noK = length(Kdef);
Ksupplied = zeros(NoS,NoS+1,noK);
fprintf('\nMaking Kernels...');
for k = 1:noK
    temp = kernel(x,x,Kdef(k).ktype,Kdef(k).kpar);
    q = 1./(diag(temp));%Normalisation
    Ksupplied(:,:,k) = [temp .* repmat(q',NoS,1) repmat(1,NoS,1)];
    temp = kernel(testx,x,Kdef(k).ktype,Kdef(k).kpar);
    testK(:,:,k) = [temp.*repmat(q',Notx^2,1) repmat(1,Notx^2,1)];
end

fprintf('\nSetting up preferences...');
%Set-up hyper-parameters
hyper.sigma = 1;
hyper.varsigma = 1;
hyper.tau = 1;
hyper.nu = 1;
hyper.update = 1;
MAXIT = 100;
KWTol = 1e-6;
SampPars.NoS = 1000;
SampPars.MAXIT = 1;
SampPars.TOL = 1e-4;

Kdef2(1).ktype = 'supplied';%Because kernel is supplied
bias = 0;
display = 1;%Just iteration text

figure(2);
fprintf('\nRunning Algorithm...');
[Ealpha, Ebeta, Omega, b, Evarphi, tau, nu] = vb_classification_dirichlet(x,t,hyper,Kdef2,bias,display,MAXIT,KWTol,SampPars,Ksupplied);

fprintf('\nMaking test kernel...');
%make test Kernel
KtestVB = Ebeta(1).*testK(:,:,1);
for k = 2:noK
    KtestVB = KtestVB + Ebeta(k).*testK(:,:,k);
end

%plot outputs
fprintf('\nPlotting outputs...');
out = (1./(1+exp(-KtestVB*Ealpha)));
A = reshape(out',Notx,Notx);
figure(1)
hold on;
contour(txr,txr,A);

%Visualise posterior
figure
vis_posterior(Omega,Evarphi,b,Ebeta);
legend('Posterior - $Q*(\beta)$','$\tilde{\beta}','Prior - $D(\tilde{\varphi})$');
title('Prior and Posterior on Simplex');