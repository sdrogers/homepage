%[Ealpha, Ebeta] = vb_classification_dirichlet(x,t,hyper,Kdef,bias,display,MAXIT,KATol,SampPars,Ksupplied)
%
%Heterogenous Kernel Combination - Variational Bayes Regression
%Copyright: Simon Rogers & Mark Girolami, March 2004
%
%INPUTS
%x - Input data points (columns = features)
%t - Targets (real values)
%hyper - Structure holding hyper-parameter values
%Kdef - Structure holding kernel definitions
%   Kdef(1).ktype = 'supplied' if Kernel is supplied by user.([N M K]
%   array)
%   Otherwise:  Kdef(i).ktype = {'rbf','linear','polynomial'}
%               Kdef(i).kpar = sigma for rbf, order for polynomial
%bias: 1 for bias, 0 otherwise (ignored if kernel is supplied by user)
%display: 0 for no feedback, 1 for iteration number, 2 for plots
%MAXIT: Maximum number of iterations
%KATol: Tolerance for change in Kernel*Alpha
%SampPars - Structure of sampling parameters
%   SampPars.NoS: Number of samples
%   SampPars.MAXIT: Number of sampling iterations
%   SampPars.TOL: Sampling tolerance
%Ksupplied: supplied kernel (optional)
%
%
%
%OUTPUTS
%Ealpha - Expected value of \alpha
%Ebeta - Expected value of \beta
function [Ealpha, Ebeta, Egamma, Ephi, hyper] = vb_regression_dirichlet(x,t,hyper,Kdef,bias,display,MAXIT,KATol,SampPars,Ksupplied)
if display > 0
  fprintf('\nHeterogenous Kernel Combination\nVB Regression\n--------------------------');
  fprintf('\nCreating Kernel: ');
end


%Create the kernel is it has not been supplied
switch Kdef(1).ktype
    case 'supplied'
        Kall = Ksupplied;
        [N,M,K] = size(Kall);
    otherwise
        [N,M] = size(x);
        M = N;
        if bias > 0
            M = M + 1;
        end
        K = length(Kdef);
        Kall = zeros(N,M,K);
        for k = 1:K
           temp = kernel(x,x,Kdef(k).ktype,Kdef(k).kpar); 
            q = (1./diag(temp));
            temp = temp.*repmat(q',N,1);
            if bias > 0
                temp = [temp repmat(1,N,1)];
            end
            Kall(:,:,k) = temp;
        end
end

%Hyper-paramaters are stored in hyper
%eg. sigma = hyper.sigma;

%Set-up Parameters
%Alpha mean and covariance
Ealpha = zeros(M,1);
Salpha = zeros(M);
Ealpha_alphaT = zeros(M);
%Phi moments
Ephi = repmat(hyper.sigma/hyper.varsigma,M,1);
Elog_phi = zeros(M,1);
%Gamma
Egamma = 0.1*var(t);

Egamma = 100;
Elog_gamma = log(Egamma);


%Beta
Ebeta = repmat(1/K,K,1);
Ebeta = rand(K,1);
Ebeta = Ebeta./sum(Ebeta);
Ebeta_betaT = repmat(1,K,K);
Elog_beta = log(Ebeta);
%Varphi
Evarphi = repmat(1,K,1);
Elog_varphi = log(Evarphi);
Elog_gamma_varphi = log(gamma(Evarphi));
Elog_gamma_sum_varphi = log(gamma(sum(Evarphi)));


%Make current matrix
thisK = zeros(N,M);
for k = 1:K
    thisK = thisK + Ebeta(k)*Kall(:,:,k);
end

%Diagnostics
Gall = [];%Evolution of Gamma
KAChange = [];KAOld = 1;%Evolution of Output function (i.e. thisK * Alpha)
Lall = [];
Aall = [];

%NOT SURE ABOUT THESE.....
Ebeta_old = repmat(0,K,1);
SumW = 0;
boundall = [];

maxpr = 4;maxpc = 2;

if display > 0
  fprintf('\nIteration: ');
end

for it = 1:MAXIT
    if display > 0
        temp = it;
        while temp > 1
            fprintf('\b');
            temp = temp/10;
        end
        fprintf('%g',it);
    end

   ppos = 1;  
   
   TempA = zeros(M);
   for i = 1:K
       for j = 1:K
            TempA = TempA + Ebeta_betaT(i,j)*(Kall(:,:,i)'*Kall(:,:,j));
       end
   end
   TempA = Egamma * TempA + diag(Ephi);
   Salpha = inv(TempA);
   Ealpha = Egamma * Salpha * (thisK' * t);
   Ealpha_alphaT = Salpha + Ealpha * Ealpha'; 
   KAChange = [KAChange;norm(thisK*Ealpha - KAOld)];
   KAOld = thisK*Ealpha;
  
   %Omega - needed often
   Omega = zeros(K);
   for i = 1:K
       for j = 1:K
        Omega(i,j) = trace(Kall(:,:,i)*Ealpha_alphaT*Kall(:,:,j)');
       end
   end

   %Calc ||e||^2
   Ee = t'*t + sum(sum(Ebeta_betaT.*Omega)) - 2*t'*(thisK*Ealpha);
   
   %Update E[gamma] and E[phi]
   %Egamma = (N + 2*hyper.rho)/(Ee + 2*hyper.varrho);
   %Elog_gamma = psi((N/2)+hyper.rho) - log((Ee/2)+hyper.varrho);
   
   Gall = [Gall;Egamma];

   %Update Phi
   Ephi = (1+2*hyper.sigma)./(diag(Ealpha_alphaT)+2*hyper.varsigma);
   
   
   if display>1
       subplot(maxpr,maxpc,ppos),bar(Ealpha);ppos = ppos + 1;
       subplot(maxpr,maxpc,ppos),bar(Ephi);ppos = ppos + 1;
       subplot(maxpr,maxpc,ppos),plot(Gall);ppos = ppos + 1;
       drawnow;
   end
   
   %Update varphi statistics with sampling
   Zphi = 0;%Estimate of normalisation factor
   SumW = 0;
   Offset = 0;
   if K>1
   Evarphi = repmat(0,K,1);
   Elog_varphi = repmat(0,K,1);
   Elog_gamma_varphi = repmat(0,K,1);
   Elog_gamma_sum_varphi = 0;
   Evarphi_old = Evarphi;
   for s_it = 1:SampPars.MAXIT
       [Evarphi, Elog_varphi, Elog_gamma_varphi, Elog_gamma_sum_varphi, SumW, Offset] = sample_varphi(...
           SampPars.NoS, Evarphi, Elog_varphi, Elog_gamma_varphi, Elog_gamma_sum_varphi,...
           SumW,hyper.tau,hyper.nu,Elog_beta,Offset);
       if norm(Evarphi - Evarphi_old)<SampPars.TOL
           break
       end
       Evarphi_old = Evarphi;
   end
   Zphi = SumW/(s_it*SampPars.NoS); 
   end

   %Update Beta with sampling
   
   b = repmat(0,K,1);
   for k = 1:K
       b(k) = sum(t.*(Kall(:,:,k)*Ealpha));
   end

   if K>1
   Zbeta = 0;
   Offset = 0;
   SumW = 0;
   Ebeta = repmat(0,K,1);
   Elog_beta = repmat(0,K,1);
   Ebeta_betaT = repmat(0,K,K);
   Ebeta_old = Ebeta;
   for s_it = 1:SampPars.MAXIT
       [Ebeta, Elog_beta, Ebeta_betaT, SumW, Offset, eflag] = sample_beta(...
           SampPars.NoS, Ebeta, Elog_beta, Ebeta_betaT, SumW, Evarphi, Egamma,Omega, b, Offset);
       if norm(Ebeta - Ebeta_old)<SampPars.TOL
           break
       end
       if eflag == -1
           break
       end
       Ebeta_old = Ebeta;
   end
   %Beta contribution to the bound
   Zbeta = SumW/(s_it*SampPars.NoS);
   end
   %Make thisK
   thisK = zeros(N,M);
   for k = 1:K
       thisK = thisK + Ebeta(k)*Kall(:,:,k);
   end
   
   if hyper.update == 1
      %Sigma
      top_const = -log((1/M)*sum(Ephi))+(1/M)*sum(Elog_phi);
      hyper.sigma = update_hyper(hyper.sigma,top_const);
      hyper.varsigma = (M*hyper.sigma)/(sum(Ephi));
      %Tau
      top_const = -log((1/K)*sum(Evarphi))+(1/K)*sum(Elog_varphi);
      hyper.tau = update_hyper(hyper.tau,top_const);
      hyper.nu = (K*hyper.tau)/(sum(Evarphi));
      %Rho
      %top_const = -log(Egamma) + Elog_gamma;
      %hyper.rho = update_hyper(hyper.rho,top_const);
      %hyper.varrho = hyper.rho/Egamma;
   end
   
   %bound = compute_bound(Ephi,Elog_phi,Ealpha,Ealpha_alphaT,Salpha,...
   %     hyper,Egamma,Elog_gamma,Ee,Evarphi,Elog_varphi,Zphi,Ebeta,Elog_beta,Zbeta,...
   %     Ebeta_betaT,Elog_gamma_varphi,N,K,Elog_gamma_sum_varphi,Omega,b);
   %bound = bound + Offset;
   %boundall = [boundall;bound];
   %if display>1
   %    if length(boundall)>20
   %        subplot(maxpr,maxpc,ppos),semilogy(boundall(20:end));ppos = ppos + 1;
   %    else
   %     subplot(maxpr,maxpc,ppos),semilogy(boundall);ppos = ppos + 1;
   %    end
      
   %    subplot(maxpr,maxpc,ppos),bar(Ebeta);ppos = ppos + 1;title('Beta');
   %    subplot(maxpr,maxpc,ppos),bar(Evarphi);ppos = ppos + 1;title('VarPhi');
   %end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function h = update_hyper(h,top_const)
hOld = h;
tol = 1e-4;
for it = 1:100
    h = hOld*exp((log(hOld) - psi(0,hOld) + top_const)/(-1+hOld*psi(1,hOld)));
    if norm(hOld-h)<tol
        break
    end
    hOld = h;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function bound = compute_bound(Ephi,Elog_phi,Ealpha,Ealpha_alphaT,Salpha,...
    hyper,Egamma,Elog_gamma,Ee,Evarphi,Elog_varphi,Zphi,Ebeta,Elog_beta,Zbeta,...
    Ebeta_betaT,Elog_gamma_varphi,N,K,Elog_gamma_sum_varphi,Omega,b)
%Alpha
bound = 0.5*sum(Elog_phi) - 0.5*sum(Ephi.*diag(Ealpha_alphaT));
bound = bound - 0.5*safe_log(det(Salpha));
%Gamma
bound = bound + hyper.rho * log(hyper.varrho) + (1-hyper.rho)*Elog_gamma - ...
       hyper.varrho * Egamma - gamma(hyper.rho);
bound = bound - ((0.5*N + hyper.rho)*log(0.5*Ee + hyper.varrho) + ...
       (0.5*N + hyper.rho - 1)*Elog_gamma - (0.5*Ee + hyper.varrho)*Egamma - log(gamma(0.5*N + hyper.varrho)));
%Phi
bound = bound -(N+1)*log(hyper.sigma) + (N+1)*hyper.sigma*log(hyper.varsigma) + ...
       (1-hyper.sigma)*sum(Elog_phi) - hyper.varsigma * sum(Ephi);
bound = bound - ((hyper.sigma + 0.5)*sum(log(hyper.varsigma + diag(Ealpha_alphaT))) + ...
       (hyper.sigma - 0.5)*sum(Elog_phi) - sum(Ephi.*(0.5*diag(Ealpha_alphaT)+hyper.varsigma)) - ...
       (N+1)*log(gamma(hyper.sigma+0.5)));
%Varphi
bound = bound -K*log(gamma(hyper.tau)) + K*hyper.tau*log(hyper.nu) + ...
       (1-hyper.tau)*sum(Elog_varphi) - hyper.nu * sum(Evarphi);
bound = bound - ( (hyper.tau - 1)*sum(Elog_varphi) + ...
       sum((Evarphi-1).*Elog_beta) - hyper.nu*sum(Evarphi) - log(Zphi) );    
%Beta
bound = bound + Elog_gamma_sum_varphi - sum(Elog_gamma_varphi) + sum((Evarphi-1).*Elog_beta);
bound = bound - ( -(Egamma/2)*sum(sum(Ebeta_betaT.*Omega)) + ...
       Egamma*Ebeta'*b + sum((Evarphi - 1).*Elog_beta) - log(Zbeta));
       
%Likelihood
bound = bound -(N/2)*log(2*pi) + (N/2)*Elog_gamma - (Egamma/2)* sum(sum(Ebeta_betaT.*Omega));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Ebeta, Elog_beta, Ebeta_betaT, SumW, Offset, exflag] = sample_beta(...
           NoS, Ebeta, Elog_beta, Ebeta_betaT, SumW, Evarphi, Egamma, Omega, b, Offset)
    %Firstly draw samples from Dirichlet with pars Evarphi
    K = length(Ebeta);
    G = repmat(0,K,NoS);
    for k = 1:K
        G(k,:) = gamrnd(Evarphi(k),1,1,NoS);
    end
    G = G./repmat(sum(G,1),K,1);
    prob = find(sum(G,1)==0);
    G(:,prob) = [];
    NoS = NoS - length(prob);
    G(find(G<1e-10)) = 1e-10;
    Q = -(Egamma/2)*(diag(G'*Omega*G)-2*G'*b)';
    if Offset == 0
        Offset = max(Q);
    end
    W = exp(Q - Offset);
    if any(isinf(W))
        I = find(isinf(W));
        exflag = -1;
        return
    end
    Ebeta = (sum(G.*repmat(W,K,1),2)+Ebeta*SumW)/(sum(W) + SumW);
    Elog_beta = (sum(log(G).*repmat(W,K,1),2)+Elog_beta*SumW)/(sum(W) + SumW);
    Ebeta_betaT = (((G.*repmat(W,K,1))*G') + Ebeta_betaT*SumW)/(sum(W) + SumW);
    exflag = 1;
    
    SumW = SumW + sum(W);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Evarphi, Elog_varphi, Elog_gamma_varphi, Elog_gamma_sum_varphi, SumW, Offset] = sample_varphi(...
           NoS, Evarphi, Elog_varphi, Elog_gamma_varphi, Elog_gamma_sum_varphi,...
           SumW,tau,nu,Elog_beta,Offset)
    %Firstly, take NoS samples from Gamma(tau,nu)
    K = length(Evarphi);
    B = gamrnd(tau,nu,K,NoS);
    %Calculate W(varphi)
    G = gamma(sum(B,1))./prod(gamma(B),1);
    T = sum((B-1).*repmat(Elog_beta,1,NoS),1);
    %if Offset == 0
    %    Offset = max(T);
    %    NewOffset = max(T);
    %else
    %    NewOffset = max(T);
    %end
    NewOffset = 0;
    W = G.*exp(T-NewOffset);
    chg = exp(NewOffset - Offset);
    Evarphi = (sum(B.*repmat(W,K,1),2)*chg+Evarphi*SumW)./(chg*sum(W)+SumW);
    Elog_varphi = (sum(log(B).*repmat(W,K,1),2)*chg+Elog_varphi*SumW)./(chg*sum(W)+SumW);
    Elog_gamma_varphi = (sum(log(gamma(B)).*repmat(W,K,1),2)*chg+Elog_gamma_varphi*SumW)./(chg*sum(W)+SumW);
    Elog_gamma_sum_varphi = (sum(log(gamma(sum(B,1))).*W,2)*chg+Elog_gamma_sum_varphi*SumW)./(chg*sum(W)+SumW);
    SumW = SumW + chg*sum(W);
    
    
    
function o = safe_log(X)

X(find(X<1e-10)) = 1e-10;
o = log(X);