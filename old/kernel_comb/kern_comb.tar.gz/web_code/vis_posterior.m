function p = vis_posterior(Omega,Evarphi,b,Ebeta)


p = 1;
g = [0.00:0.02:1.0];
for i = 1:length(g)
  for j = 1:length(g)
    Beta(1,1) = g(i);
    Beta(2,1) = g(j);
    if Beta(1)+Beta(2)>1
      continue
    else
      Beta(3,1) = 1-(Beta(1)+Beta(2));
      Beta = Beta + 0.001;
      
      %M(i,j) = sum(log(Beta.^(Evarphi-1))) + (-0.5*(Beta'*Omega*Beta - ...
      %                                       Beta'*b));
      M(i,j) = prod(Beta.^(Evarphi-1)) *exp(-0.5*(Beta'*Omega*Beta - ...
                                             Beta'*b));
                                         
    end
  end
end
M = M./(sum(sum(M)));
contour(g,g,M,10,'r','linewidth',1);
hold on
plot(Ebeta(2),Ebeta(1),'ko');
hold off
%surf(g,g,M);
for i = 1:length(g)
  for j = 1:length(g)
    Beta(1,1) = g(i);
    Beta(2,1) = g(j);
    if Beta(1)+Beta(2)>1
      continue
    else
      Beta(3,1) = 1-(Beta(1)+Beta(2));
      Beta = Beta + 0.001;
      %M(i,j) = sum(log((Beta.^(Evarphi-1))));
      M(i,j) = prod(Beta.^(Evarphi-1));
    end
  end
end
M = M./sum(sum(M));
%figure(2)
hold on
contour(g,g,M,30);
hold off;

