#include "Main.h"
void c_LDA::InitialiseValues(c_LDAData *pData)
{
  /* Set means to the data means */
  for(int g=0; g<this->nGenes; g++)
    {
      double fAverage = 0.0;

      for(int i=0; i<this->nSample; i++) if(pData->apcOriginalSample[i]->abData[g]) fAverage += pData->apcOriginalSample[i]->afData[g];
	
      fAverage /= static_cast<double>(this->nSample);

      for(int k=0; k<nProcess; k++) this->aafMeans[g][k] = fAverage;
    }
  /* ----------- */

  /* Set vars to the data variation */
  for(int g=0; g<nGenes; g++)
    {
      double fVar = 0;

      for(int i=0; i<nSample; i++) if(pData->apcOriginalSample[i]->abData[g]) fVar += pow(aafMeans[g][0] - pData->apcOriginalSample[i]->afData[g], 2);

      fVar /= static_cast<double>(nSample);
      for(int j=0; j<nProcess; j++) this->aafVars[g][j] = fVar;
    }
  this->SmoothVars(pData);
  /* ----------- */

  /* Alpha ones */
  for(int i=0; i<nProcess; i++) this->afAlpha[i] = 1.0;
  /* ----------- */
}

c_LDA::c_LDA(c_LDAData *pData, bool bSetPriors, double fMeanP, double *afVarsP)
{
  /* Initialise and allocate a c_LDA */
  this->nGenes = pData->nGenes;
  this->nSample = pData->nSample;
  this->nProcess = pData->nProcess;

  /* Parameters of the prior distributions */
  this->bPriors = bSetPriors;   
  this->fMeanPrior = fMeanP;
  if(afVarsP)
    {
      this->afVarsPrior = new double[3];
      for(int i=0; i<3; i++) this->afVarsPrior[i] = afVarsP[i];
    }
  /* ------------ */


  /* model variables*/
  nAllocateArray(&this->aafMeans, this->nGenes, this->nProcess);
  nAllocateArray(&this->aafVars, this->nGenes, this->nProcess);
  this->afAlpha = new double [this->nProcess];
  /* ----------- */


  /* Initialise Data */
  this->InitialiseValues(pData);
  /* ----------- */
}


c_LDA::~c_LDA()
{
  delete [] afVarsPrior;
  nFreeArray(&aafMeans, nGenes);
  nFreeArray(&aafVars, nGenes);
  delete [] afAlpha;
}
