#include "Main.h"


void c_LDA::DoLPD(c_LDAData *pData)
{
  int     nRep       = 0;                     /* current number of iterations we have done */
  double *afOldAlpha = new double[nProcess];  /* previous value of alpha */

  while(nRep < pData->nReps)
    {
      /* Update Latent variables */
      this->UpdatePhi(pData);
      this->UpdateGamma(pData);
      /* ----------------------- */

      /* Update Model parameters */
      this->UpdateMean(pData);
      this->UpdateVars(pData);

      for(int k=0; k<nProcess; k++) afOldAlpha[k] = this->afAlpha[k];
      UpdateAlpha(pData);
      /* ----------------------- */
      
      double fChange = 0.0;
      for(int k=0; k<nProcess; k++) fChange += fabs(afOldAlpha[k] - afAlpha[k]);

      /* If we have improved by less than epsilon then exit */
      if(fChange < 0.0000001) break;
      /* ------------------------- */

      /* Every turn output alpha */
      if(nRep)
	{
	  cout << "Loop" << nRep << " Alpha Change" << " " << fChange << endl;
	  for(int k=0; k<pData->nProcess; k++) cout << this->afAlpha[k] << " ";
	  cout << endl;    
	}
      nRep++;
    }

  delete [] afOldAlpha;

  /* Calculate the likelihood and output */
  cout << "LogLikelihood " <<  this->LogLikelihood(pData) << endl;
}
