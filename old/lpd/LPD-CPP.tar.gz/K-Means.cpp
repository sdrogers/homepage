#include "Main.h"
#define M 2.0

/* IMPLEMENTATION OF A BASIC K-MEANS CLUSTERING FOR INITIALISATION */

/* Create a new K-Means object */
c_KMeans::c_KMeans(int nProcess, int nGenes)
{
  nCenters = nProcess;
  nFeat    = nGenes;

  nAllocateArray(&aafCenters, nCenters, nFeat);
}
/* destroy a K-Means object */
c_KMeans::~c_KMeans()
{
  nFreeArray(&this->aafCenters, this->nCenters);
}



/* Calculates distance to center k from given point */
void c_KMeans::CalcDist(double *afFeats, bool *abFeats, int k, double *pfDist)
{
  double fDist = 0.0;

  for(int f=0; f<nFeat; f++) if(abFeats[f]) fDist += aafCenters[k][f] - afFeats[f];
      
  *pfDist = fabs(fDist);
}
/* Loop through all cluster centers and find the nearest */
int c_KMeans::nFindNearestCenter(double *afFeats, bool *abFeats)
{
  double fMinDist = BIG_NUMBER;
  int    nIndex;

  for(int k=0; k<nCenters; k++)
    {
      double fDist = 0.0;

      this->CalcDist(afFeats, abFeats, k, &fDist);

      if(fDist < fMinDist)
	{
	  fMinDist = fDist;
	  nIndex = k;
	}
    }
  return nIndex;
}

void c_KMeans::UpdateMembership(c_LDAData *pData, int nType)
{
  if(nType == 1)
    {
      for(int i=0; i<pData->nSample; i++)
	{
	  int  nIndex = this->nFindNearestCenter(pData->apcSample[i]->afData, pData->apcSample[i]->abData);
	  bool bMatch = false;
	
	  for(int k=0; k<nCenters; k++) 
	    {
	      if(k == nIndex)
		{
		  for(int g=0; g<pData->nGenes; g++) if(pData->apcSample[i]->abData[g]) pData->apcSample[i]->aafPhi[g][k] = 1;
		  bMatch = true;
		}
	      else
		{
		  for(int g=0; g<pData->nGenes; g++) if(pData->apcSample[i]->abData[g]) pData->apcSample[i]->aafPhi[g][k] = 0;
		}
	    }
	  if(!bMatch)
	    {
	      this->nFindNearestCenter(pData->apcSample[i]->afData, pData->apcSample[i]->abData);
	    }
	}
    }
  else
    {
      /* Fuzzy k-means */
      /* First update then normalise */
      for(int i=0; i<pData->nSample; i++)
	{
	  for(int k=0; k<nCenters; k++) 
	    {     
	      double fDist = 0;
	      
	      this->CalcDist(pData->apcSample[i]->afData, pData->apcSample[i]->abData, k, &fDist);
	      for(int g=0; g<pData->nGenes; g++) if(pData->apcSample[i]->abData[g]) pData->apcSample[i]->aafPhi[g][k] = fDist;
	    }
	}
      for(int i=0; i<pData->nSample; i++)
	{
	  double fSum = 0.0;

	  for(int k=0; k<nCenters; k++) 
	    {     
	      for(int g=0; g<pData->nGenes; g++) if(pData->apcSample[i]->abData[g]) fSum += pow(pData->apcSample[i]->aafPhi[g][k], 2/(1-M));
	    }
	  for(int k=0; k<nCenters; k++) 
	    {
	      for(int g=0; g<pData->nGenes; g++) if(pData->apcSample[i]->abData[g]) pData->apcSample[i]->aafPhi[g][k] = pow(pData->apcSample[i]->aafPhi[g][k], 2/(1-M)) / fSum;
	    }
	}

    }
}

void c_KMeans::UpdateCenters(c_LDAData *pData, int nType)
{
  double **aafOld = NULL;

  nAllocateArray(&aafOld, nCenters, pData->nGenes);
  for(int k=0; k<nCenters; k++) for(int g=0; g<pData->nGenes; g++) aafOld[k][g] = aafCenters[k][g];

  if(nType == 1)
    {
      double **aafC = NULL;
      int    **aanElements = NULL;

      nAllocateArray(&aanElements, nCenters, pData->nGenes);
      nAllocateArray(&aafC, nCenters, pData->nGenes);

      for(int i=0; i<pData->nSample; i++)
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      if(pData->apcSample[i]->abData[g]) 
		for(int k=0; k<pData->nProcess; k++)
		  {
		    if(fabs(pData->apcSample[i]->aafPhi[g][k] - 1) < 0.01)
		      {
			aanElements[k][g]++;
			aafC[k][g] += pData->apcSample[i]->afData[g];
			break;
		      }
		  }
	    }
	}
      for(int k=0; k<nCenters; k++)
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      if(aanElements[k][g])
		aafCenters[k][g] = aafC[k][g] / static_cast<double>(aanElements[k][g]);
	    }
	}

      nFreeArray(&aanElements, nCenters);
      nFreeArray(&aafC, nCenters);
    }
  else
    {
      double **aafC       = NULL;
      double **aafMembSum = NULL;

      nAllocateArray(&aafC, nCenters, pData->nGenes);
      nAllocateArray(&aafMembSum, nCenters, pData->nGenes);

      for(int i=0; i<pData->nSample; i++)
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      if(pData->apcSample[i]->abData[g]) 
		for(int k=0; k<pData->nProcess; k++)
		  {
		    aafMembSum[k][g] += pow(pData->apcSample[i]->aafPhi[g][k], M);
		    aafC[k][g] += pow(pData->apcSample[i]->aafPhi[g][k], M) * pData->apcSample[i]->afData[g];
		  }
	    }
	}
      for(int k=0; k<nCenters; k++)
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      aafCenters[k][g] = aafC[k][g] / static_cast<double>(aafMembSum[k][g]);
	    }
	}

      nFreeArray(&aafC, nCenters);     
      nFreeArray(&aafMembSum, nCenters);     
    }
  double fChange = 0.0;
  for(int k=0; k<nCenters; k++) for(int g=0; g<pData->nGenes; g++) fChange += fabs(aafOld[k][g] - aafCenters[k][g]);

  nFreeArray(&aafOld, nCenters);

}

void c_LDA::InitialiseKMeans(c_LDAData *pData, int nType)
{
  /* Find K centers, rand between max and min on each dimension 
   *  nType = 1, standard nType=2 fuzzy */
  
  if(nType != 1 && nType != 2) 
    {
      cout << "Error in K-Means Cluster Type" << endl;
      return;
    }
  else
    {
      if(nType == 1)
	cout << "C-Means Clustering Initialisation ";
      else
	cout << "Fuzzy C-Means Clustering Initialisation ";
      cout << endl;
    }

  c_KMeans *pKMeans = new c_KMeans(nProcess, nGenes);

  double *afMin = new double[nGenes];
  double *afMax = new double[nGenes];

  for(int g=0; g<nGenes; g++)
    {
      afMin[g] = BIG_NUMBER;
      afMax[g] = -BIG_NUMBER;
    }

  if(nType == 1)
    for(int i=0; i<pData->nSample; i++) for(int g=0; g<pData->nGenes; g++) for(int k=0; k<nProcess; k++) pData->apcSample[i]->aafPhi[g][k] = 0;

  for(int i=0; i<pData->nSample; i++)
    {
      for(int g=0; g<nGenes; g++)
	{
	  if(pData->apcSample[i]->abData) 
	    {
	      if(afMin[g] > pData->apcSample[i]->afData[g])
		afMin[g] = pData->apcSample[i]->afData[g];
	      if(afMax[g] < pData->apcSample[i]->afData[g])
		afMax[g] = pData->apcSample[i]->afData[g];
	    }
	}
    }

  for(int k=0; k<nProcess; k++)
    {
      for(int g=0; g<pData->nGenes; g++)
	{
	  pKMeans->aafCenters[k][g] = afMin[g] + (afMax[g] - afMin[g]) * (static_cast<double>(rand())/static_cast<double>(RAND_MAX));
	}
    }
  
  for(int nRep = 0; nRep < 100; nRep++)
    {
      pKMeans->UpdateMembership(pData, nType);
      pKMeans->UpdateCenters(pData, nType);
    }

  if(nType == 1)
    {
      for(int k=0; k<nProcess; k++)
	{
	  for(int g=0; g<pData->nGenes; g++) 
	    {
	      double fSum = 0.0;

	      for(int i=0; i<pData->nSample; i++)
		{
		  if(pData->apcSample[i]->abData[g]) fSum += pData->apcSample[i]->aafPhi[g][k] * pKMeans->aafCenters[k][g];
		}
	      aafMeans[g][k]  = fSum / static_cast<double>(pData->nSample);
	    }
	}
      for(int k=0; k<nProcess; k++)
	{
	  for(int g=0; g<pData->nGenes; g++) 
	    {
	      double fSum = 0.0;

	      for(int i=0; i<pData->nSample; i++)
		{
		  if(pData->apcSample[i]->abData[g]) fSum += pow(pData->apcSample[i]->aafPhi[g][k] * pKMeans->aafCenters[k][g] - aafMeans[g][k], 2);
		}
	      aafMeans[g][k]  = fSum / static_cast<double>(pData->nSample);
	    }
	}
    }

  delete pKMeans;
  delete [] afMin;
  delete [] afMax;
}
