#include "Main.h"

GFNS gfns;

/* Returns log but checks for small numbers */
double New_log(double f)
{
  if(f < SMALL_NUMBER) return log(SMALL_NUMBER);
  else return log(f);
}

/* returns a gaussian density for a single gene and process */
void c_LDA::Norm_Pdf(double *pfValue, c_LDASample *pSample, int nCurrentProcess, int nCurrentGene)
{
  if(!pSample->abData[nCurrentGene]) 
    {
      cout << "Data not available" << endl;
    }
  
  double fXn = (pSample->afData[nCurrentGene] - aafMeans[nCurrentGene][nCurrentProcess]) / sqrt(aafVars[nCurrentGene][nCurrentProcess]);

  *pfValue = exp(-0.5 * pow(fXn,2)) / (sqrt(2*PI * aafVars[nCurrentGene][nCurrentProcess]));
}

/* calculates the bound we are maximizing - this was used for testing */
double c_LDA::Bound(c_LDAData *pData)
{
  double fTerm1 = 0.0;
  /* Find the normal density for each genes expression in each sample for each process */
  for(int i=0; i<pData->nSample; i++)
    {
      c_LDASample *pSample = pData->apcSample[i];

      for(int g=0; g<pSample->nGenes; g++)
	{
	  if(pSample->abData[g]) 
	    {
	      for(int k=0; k<pSample->nProcess; k++)
		{
		  double fVal = 0.0;
		  
		  this->Norm_Pdf(&fVal, pSample, k, g);
		  fTerm1 += pSample->aafPhi[g][k] * log(fVal);
		}
	    }
	}
    }
  double fTerm2 = 0.0;
  for(int i=0; i<pData->nSample; i++)
    {
      c_LDASample *pSample = pData->apcSample[i];

      for(int g=0; g<pSample->nGenes; g++)
	{
	  if(pSample->abData[g]) 
	    {
	      for(int k=0; k<pSample->nProcess; k++)
		{
		  fTerm2 += pSample->aafPhi[g][k] * log(pSample->aafPhi[g][k]);
		}
	    }
	}
    }
  double fTerm3 = 0.0;
  for(int i=0; i<pData->nSample; i++)
    {
      c_LDASample *pSample = pData->apcSample[i];

      for(int g=0; g<pSample->nGenes; g++)
	{
	  if(pSample->abData[g]) 
	    {
	      for(int k=0; k<pSample->nProcess; k++)
		{
		  fTerm3 += pSample->aafPhi[g][k] * ELogThetaGamma(i, k, pData);
		}
	    }
	}
    }
  double fTerm4 = 0.0;
  for(int i=0; i<pData->nSample; i++) 
    {
      double fSumAlpha = 0.0;
      for(int k=0; k<this->nProcess; k++) fSumAlpha += this->afAlpha[k];
      fTerm4 += gfns.gammalog(fSumAlpha);

      for(int k=0; k<this->nProcess; k++) fTerm4 -= gfns.gammalog(this->afAlpha[k]);
      for(int k=0; k<this->nProcess; k++) fTerm4 += (this->afAlpha[k] - 1) * ELogThetaGamma(i, k, pData);
    }
  double fTerm5 = 0.0;

  for(int i=0; i<pData->nSample; i++) 
    {
      c_LDASample *pSample = pData->apcSample[i];

      double fSumGamma = 0.0;
      for(int k=0; k<this->nProcess; k++) fSumGamma += pSample->afGamma[k];
      fTerm5 += gfns.gammalog(fSumGamma);
      
      for(int k=0; k<this->nProcess; k++) fTerm5 -= gfns.gammalog(pSample->afGamma[k]);
      for(int k=0; k<this->nProcess; k++) fTerm5 += (pSample->afGamma[i] - 1) * ELogThetaGamma(i, k, pData);
    }

  fTerm1 /= static_cast<double>(pData->nSample);
  fTerm2 /= static_cast<double>(pData->nSample);
  fTerm3 /= static_cast<double>(pData->nSample);
  fTerm4 /= static_cast<double>(pData->nSample);
  fTerm5 /= static_cast<double>(pData->nSample);

  cout << "B1 " << fTerm1 << " " << fTerm2 << " " << fTerm3 << " " << fTerm4 << " " << fTerm5 << endl;
  cout << "B2 " << fTerm1 - fTerm2 + fTerm3 + fTerm4 - fTerm5 << endl;
}

/* loglikelihood */
double c_LDA::LogLikelihood(c_LDAData *pData)
{
  int       nGammaSamp     = 200;  /* we approximate an integral numerically, this is the number of points used */
  double    fLogLikelihood = 0.0;
  double  **aafTheta       = NULL;
  double ***aaafNormal     = NULL; /* PDF for gene g and process k */

  nAllocateArray(&aafTheta, nGammaSamp, nProcess);
  nAllocateArray(&aaafNormal, pData->nTestSample, nGenes, nProcess);

  /* Sample theta from a gamma distribution */
  for(int n=0; n<nGammaSamp; n++)
    {
      double fSum = 0.0;

      for(int k=0; k<nProcess; k++)
	{
	  aafTheta[n][k] = gfns.gamrnd(afAlpha[k]);
	  fSum += aafTheta[n][k];
	}
      for(int k=0; k<nProcess; k++) aafTheta[n][k] /= fSum;
    }
  /* Find the normal density for each genes expression in each sample for each process */
  for(int i=0; i<pData->nTestSample; i++)
    {
      c_LDASample *pSample = pData->apcTestSample[i];

      for(int g=0; g<pSample->nGenes; g++)
	{
	  if(pSample->abData[g]) 
	    {
	      for(int k=0; k<pSample->nProcess; k++)
		{
		  this->Norm_Pdf(&(aaafNormal[i][g][k]), pSample, k, g);
		}
	    }
	}
    }

  double *afMax = new double[pData->nSample];
 
  for(int i=0; i<pData->nTestSample; i++) afMax[i] = -BIG_NUMBER; /* Used to get around the small numbers */

  for(int i=0; i<pData->nTestSample; i++)
    {
      for(int n=0; n<nGammaSamp; n++)
	{
	  /* Prod over g written as a sum over the logs */
	  double fSumLogG = 0.0;

	  for(int g=0; g<nGenes; g++)
	    {
	      if(pData->apcTestSample[i]->abData[g]) 
		{
		  double fSumK = 0.0;
		  
		  for(int k=0; k<nProcess; k++)
		    {
		      fSumK += aaafNormal[i][g][k] * aafTheta[n][k];
		    }
		  fSumLogG += New_log(fSumK);
		}
	    }
	  if(fSumLogG > afMax[i]) afMax[i] = fSumLogG;
	}
    }
  for(int i=0; i<pData->nTestSample; i++)
    {
      c_LDASample *pSample = pData->apcTestSample[i];
      double       fSumN   = 0.0;

      for(int n=0; n<nGammaSamp; n++)
	{
	  /* Prod over g written as a sum over the logs */
	  double fSumLogG = 0.0;

	  for(int g=0; g<pSample->nGenes; g++)
	    {
	      if(pSample->abData[g]) 
		{
		  double fSumK = 0.0;
		  
		  for(int k=0; k<pSample->nProcess; k++)  fSumK += aaafNormal[i][g][k] * aafTheta[n][k];
		  
		  fSumLogG += New_log(fSumK);
		}
	    }
	  fSumN += exp(fSumLogG - afMax[i]);
	}
      double tmp = New_log(fSumN) + afMax[i] - log(nGammaSamp);
      fLogLikelihood += New_log(fSumN) + afMax[i] - log(nGammaSamp);
    }

  fLogLikelihood /= static_cast<double>(pData->nTestSample);

  this->fLL = fLogLikelihood;

  delete [] afMax;
  nFreeArray(&aafTheta, nGammaSamp);
  nFreeArray(&aaafNormal, pData->nTestSample, nGenes);

  return fLogLikelihood;
}

void c_LDA::Norm_Pdf_Parts(double **pafExpArgs, double **pafDenom, int nCurrentProcess, c_LDASample *pSample)
{
  /* Returns the exponential part and the denominator of a gaussian pdf separately */

  for(int g=0; g<pSample->nGenes; g++)
    {
      if(pSample->abData[g])
	{
	  double fXn = (pSample->afData[g] - aafMeans[g][nCurrentProcess]) / sqrt(aafVars[g][nCurrentProcess]);

	  (*pafExpArgs)[g] = -0.5 * pow(fXn,2);
	  (*pafDenom)[g] = (sqrt(2*PI * aafVars[g][nCurrentProcess]));
	}
    }
}

void c_LDA::UpdatePhi(c_LDAData *pData)
{
  for(int i=0; i<pData->nSample; i++)
    {
      UpdateIndividualPhi(pData->apcSample[i]);
    }
  pData->SmoothPhi();
  pData->NormalisePhi();
}

void c_LDA::UpdateIndividualPhi(c_LDASample *pSample)
{
  /* Special implementation to deal with big and small numbers */
  double fSumGamma = 0.0;
  for(int k=0; k<nProcess; k++) fSumGamma += pSample->afGamma[k];

  double **aafTotalExpArgs = NULL;   /* This is the eponential arguement for all k processes and g genes */
  double **aafDenom        = NULL;
  double   fMax            = 0;

  nAllocateArray(&aafTotalExpArgs, nProcess, nGenes);
  nAllocateArray(&aafDenom, nProcess, nGenes);

  /* Find all the exponential args and the maximum of these over genes and processes*/
  for(int k=0; k<nProcess; k++)
    {
      double *afExpArgs1 = new double[pSample->nGenes]; /* This is a store for the gaussian part */

      Norm_Pdf_Parts(&afExpArgs1, &(aafDenom[k]), k, pSample);

      double fExpArgs2 = gfns.polygamma(pSample->afGamma[k], 0); /* poly gamma part */

      for(int g=0; g<nGenes; g++) 
	{
	  if(pSample->abData[g]) 
	    {
	      aafTotalExpArgs[k][g] = afExpArgs1[g] + fExpArgs2; 

	      if(fMax < aafTotalExpArgs[k][g]) fMax = aafTotalExpArgs[k][g];
	    }
	}

      delete [] afExpArgs1;
    }
  /* fMax is a constant exponential factor and so on normalisation of phi it will cancel*/
  for (int k=0; k<nProcess; k++)
    {
      for(int g=0; g<pSample->nGenes; g++) 
	{
	  if(pSample->abData[g]) 
	    {
	      pSample->aafPhi[g][k] = exp(-fMax + aafTotalExpArgs[k][g]) / aafDenom[k][g];
	      if(isnan(pSample->aafPhi[g][k]) || isinf(pSample->aafPhi[g][k]))
		{
		  printf("Nan Phi\n");
		  exit(1);
		}
	    }
	}
    }
  nFreeArray(&aafTotalExpArgs, nProcess);
  nFreeArray(&aafDenom, nProcess);
}

void c_LDA::UpdateGamma(c_LDAData *pData)
{
  /* \gamma_k = \alpha_k + \sum( \phi_{nk}) */
  for(int i=0; i<pData->nSample; i++)
    {
      UpdateIndividualGamma(pData->apcSample[i]);
    }
}

void c_LDA::UpdateIndividualGamma(c_LDASample *pSample)
{
  /* Gamma_k = Alpha_k + Sum( Phi_n_k) */

  for(int k=0; k<pSample->nProcess; k++)
    {
      double fSum = 0.0;

      fSum += afAlpha[k];
      for(int g=0; g<pSample->nGenes; g++) if(pSample->abData[g]) 
	{
	  fSum += pSample->aafPhi[g][k];
	  if(isnan(fSum))
	    cout << "NaN Gamma" << endl;	
	}  

      pSample->afGamma[k] = fSum;

    }
}

void c_LDA::UpdateAlpha(c_LDAData *pData)
{
  double  *afH       = new double[pData->nProcess];
  double  *afGrad    = new double[pData->nProcess];
  double   fSumAlpha = 0.0;

  /* Find Sum over Gamma and Sum over Alpha */
  for(int k=0; k<pData->nProcess; k++) fSumAlpha += afAlpha[k];
  
  double  *afSumGamma = new double[pData->nSample];
  for(int i=0; i<pData->nSample; i++) 
    {
      afSumGamma[i] = 0.0;
      for(int k=0; k<pData->nProcess; k++) afSumGamma[i] += pData->apcSample[i]->afGamma[k];
    }

  /* Find 'diagonal' elements of hessian */
  /* - M * Phi'(Alpha_i) */
  for(int i=0; i<pData->nProcess; i++) afH[i] = -pData->nSample * gfns.polygamma(afAlpha[i], 1);
  /* fTGSumAlpha */
  double fZ = pData->nSample * gfns.polygamma(fSumAlpha, 1); /* This is the z in the formula */

  /* Find gradient */
  /* 1. Find Alpha Terms  - GAMMA( Sum <Alpha ), GAMMA(Alpha) */
  double fDGSumAlpha = gfns.polygamma(fSumAlpha, 0); 
  double *afDGAlpha   = new double[pData->nProcess];
  for(int k=0; k<pData->nProcess; k++) afDGAlpha[k] = gfns.polygamma(afAlpha[k], 0);

  /* 2. Find Gammas */
  /* 3rd element in gradient */
  double *afSumDGGamma = new double[pData->nProcess];
  for(int k=0; k<pData->nProcess; k++) 
    {
      afSumDGGamma[k] = 0.0;
      for(int i=0; i<pData->nSample; i++) afSumDGGamma[k] += gfns.polygamma(pData->apcSample[i]->afGamma[k], 0);
    }

  /* 4th element in gradient */
  double fSumDGSumGamma = 0.0;
  for(int i=0; i<pData->nSample; i++)
    {
      fSumDGSumGamma += gfns.polygamma(afSumGamma[i], 0);
    }
  for(int k=0; k<pData->nProcess; k++) 
    {
      afGrad[k] = pData->nSample * (fDGSumAlpha -  afDGAlpha[k]) + afSumDGGamma[k] - fSumDGSumGamma;
    }

  /* Find inverse (not explicitly) - using technique Blei,Ng & Jordan pg 1018 */

  double fBottom = 1.0 / fZ;
  for(int k=0; k<pData->nProcess; k++) fBottom += (1.0 / afH[k]);
  
  double fC = 0.0;
  for(int k=0; k<pData->nProcess; k++) fC += (afGrad[k] / afH[k]);
  fC /= fBottom;

  /* Now to update Alpha_new = Alpha_old - (H^-1)g*/
  for(int k=0; k<pData->nProcess; k++)
    {
      double fUpdate = (afGrad[k] - fC) / afH[k];
      afAlpha[k] -= fUpdate;
      if(isnan( afAlpha[k]))
	cout << "NaN Alpha" << endl;
    }
  
  delete [] afSumGamma;
  delete [] afDGAlpha;
  delete [] afSumDGGamma;

  SmoothAlpha(pData);

  delete [] afGrad;
  delete [] afH;
}


double c_LDA::ELogThetaGamma(int nSample, int nCurrProcess, c_LDAData *pData)
{
  double fSum = 0.0;

  for(int k=0; k<nProcess; k++) fSum += pData->apcSample[nSample]->afGamma[k];

  return gfns.polygamma(pData->apcSample[nSample]->afGamma[nCurrProcess], 0) - gfns.polygamma(fSum, 0);
}

void c_LDA::UpdateMean(c_LDAData *pData)
{
  /* \mu_{gk} = \sum_i \phi_{igk} * e_{ig} / \sum_i \phi_{igk} */
  for(int k=0; k<pData->nProcess; k++) 
    {
      for(int g=0; g<pData->nGenes; g++)
	{
	  double fBottom = 0.0;
	  for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fBottom += pData->apcSample[i]->aafPhi[g][k];
	  
	  double fTop = 0.0;

	  for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fTop += pData->apcSample[i]->aafPhi[g][k] * pData->apcSample[i]->afData[g];

	  aafMeans[g][k] = fTop / fBottom;
	}
    }
}

void c_LDA::UpdateVars(c_LDAData *pData)
{  
  if(bPriors)
    {
      /* */ 
      for(int k=0; k<pData->nProcess; k++) 
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      double fA = afVarsPrior[2];
	      for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fA -= pData->apcSample[i]->aafPhi[g][k];

	      double fB = -afVarsPrior[1];

	      double fC = -2 * afVarsPrior[0];
	      for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fC += pData->apcSample[i]->aafPhi[g][k] * pow(pData->apcSample[i]->afData[g] - aafMeans[g][k], 2);

	      aafVars[g][k] = pow((-fB + sqrt(pow(fB, 2) - 4 * fA * fC)) / (2 * fA), 2);
	    }
	}
    }
  else
    {
      /* */
      for(int k=0; k<pData->nProcess; k++) 
	{
	  for(int g=0; g<pData->nGenes; g++)
	    {
	      double fBottom = 0.0;
	      for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fBottom += pData->apcSample[i]->aafPhi[g][k];

	      double fTop = 0.0;
	      for(int i=0; i<pData->nSample; i++) if(pData->apcSample[i]->abData[g]) fTop += pData->apcSample[i]->aafPhi[g][k] * pow(pData->apcSample[i]->afData[g] - aafMeans[g][k], 2);
	  
	      aafVars[g][k] = fTop / fBottom;
	    }
	}
    }
}

void c_LDA::LoadData(c_LDAData *pData)
{  
  ifstream file;
  
  file.open("Means.txt");
  for(int g=0; g<pData->nGenes; g++) 
    {
      for(int k=0; k<pData->nProcess; k++) file >> aafMeans[g][k];
    }
  file.close();

  file.open("Vars.txt");
  for(int g=0; g<pData->nGenes; g++) 
    {
      for(int k=0; k<pData->nProcess; k++) file >> aafVars[g][k];
    }
  file.close();

  file.open("Alpha.txt");
  for(int k=0; k<pData->nProcess; k++) file >>  afAlpha[k];
  file.close();

}
