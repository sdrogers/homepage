#include "Main.h"

void c_LDAData::LoadData()
{
  ifstream file;

  file.open("Gamma.txt");
  for(int i=0; i<nSample; i++) 
    {
      double fSum = 0.0;
      for(int k=0; k<nProcess; k++) file >> apcSample[i]->afGamma[k];
    }
  file.close();

  file.open("Phi.txt");
  for(int i=0; i<nSample; i++)
    {
      for(int g=0; g<apcSample[i]->nGenes; g++) 
	{	
	  for(int k=0; k<nProcess; k++) file >>  apcSample[i]->aafPhi[g][k];
	}

    }
  file.close();
}

void vCreatePermutation(int **panPerm, int nOriginalSample)
{
  /* Created a random permutation 0 to (OriginalSample - 1) */
  int *anPool = new int[nOriginalSample];        /* Pool of numbers to be used in the permutation */
  bool bFinished = false;                        

  *panPerm = new int[nOriginalSample];

  for(int i=0; i<nOriginalSample; i++) anPool[i] = i;

  int nDone = 0;
  while(nDone != nOriginalSample)
    {
      /* Random number between 0 and nOriginalSample-1 */
      int nRand = static_cast<int>(floor(nOriginalSample * ((double)rand()/(double)RAND_MAX)));
      
      if(anPool[nRand] != -1) 
	{
	  (*panPerm)[nDone] = anPool[nRand];
	  nDone++;
	  anPool[nRand] = -1;
	}
    }
  delete [] anPool;
}

void c_LDAData::InitialiseData()
{
  for(int i=0; i<nSample; i++) this->apcSample[i]->InitialiseSample();
}

c_LDAData::c_LDAData(char *szDataFileName, int nSetProcess, int nSetReps)
{
  /* Data is in the form
  
  nSample nGenes
  (1st)        gene[0] ...... gene[nGenes]
  ..
  (nSample'th) gene[0] ...... gene[nGenes]
  */

  ifstream *pDataFile = new ifstream(szDataFileName);

  /* Check for valid file */
  if(!pDataFile->is_open()) 
    {
      cout << "Unable to open file " << szDataFileName << endl << "Exiting...." << endl;
      exit(0);
    }

  *pDataFile >> nOriginalSample;
  *pDataFile >> nGenes;

  apcOriginalSample = new c_LDASample*[nOriginalSample];
  int nCurrentSample = 0;

  while(nCurrentSample < nOriginalSample)
    {
      apcOriginalSample[nCurrentSample] = new c_LDASample(nGenes, pDataFile, nSetProcess);
      apcOriginalSample[nCurrentSample]->nId = nCurrentSample;
      nCurrentSample++;
    }

  /* Do Leave 10% out cross validation */
    nSample = static_cast<int>(floor(0.9 * nOriginalSample));
  int *anPerm = NULL;

  vCreatePermutation(&anPermutation, nOriginalSample);
  
  /* Enough space for any eventuality */
  apcSample = new c_LDASample*[nOriginalSample];
  for(int i=0; i<nOriginalSample; i++) apcSample[i] = NULL;

  nTestSample = nOriginalSample - nSample;
  apcTestSample = new c_LDASample*[nOriginalSample];
  for(int i=0; i<nOriginalSample; i++) apcTestSample[i] = NULL;

  nProcess = nSetProcess;
  nReps = nSetReps;

  pDataFile->close();

  delete pDataFile;
  delete [] anPerm;
}

c_LDAData::~c_LDAData()
{
  int nCurrentSample = 0;

  for(int i=0; i < nOriginalSample; i++) delete apcOriginalSample[i];

  delete [] apcOriginalSample;

  /* These were just arrays of pointers */
  delete [] apcSample;
  delete [] apcTestSample;

  delete [] anPermutation;
}


void c_LDAData::SmoothPhi()
{
  for(int i=0; i<nSample; i++) apcSample[i]->SmoothPhi();
}
void c_LDAData::SmoothGamma()
{
  for(int i=0; i<nSample; i++) apcSample[i]->SmoothGamma();
}
void c_LDAData::NormalisePhi()
{
  for(int i=0; i<nSample; i++) apcSample[i]->NormalisePhi();
}


