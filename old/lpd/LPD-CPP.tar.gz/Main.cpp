#include "Main.h"

int main(int argc, char *argv[])
{
  c_LDAData      *pData        = NULL;          /* Data class */
  c_LDA          *pLDA         = NULL;          /* LDA class */
  bool            bLoadData    = false;         /* Do we want to continue from where we left off and load the text files */
  char           *szTrainFile  = NULL;          /* File contaning all the data - NB THIS IS JUST A POINTER TO argv*/
  int             nChosenProc  = 0;             /* Number of processes */
  int             nChosenRep   = 0;             /* Number of iterations */
  double          fMeanPrior   = 0.0;           /* Prior for the means, at the moment this is not implemented (equivalent to zero) */
  double         *afVarsPrior  = NULL;          /* Values of k1 k2 and k3 in the vars prior */
  bool            bPriors      = false;         /* Are we doing priors */
  bool            bCrossV      = false;         /* Are we cross validating into 10 hold out cases */

  if(argc == 6)
    {
      /* No prior set */
    }
  else if(argc == 10)
    {
      /* Priors are set */
      bPriors = true;
      afVarsPrior = new double[3];
    }
  else
    {
      cout << "Usage File - Processes - Iterations - bLoadData - bCrossValidate - (MeanPrior - VarsPrior1 VarsPrior2 VarsPrior3)" << endl;
      cout << "Last parameters are optional" << endl;
      exit(1);
    }
  
  szTrainFile = argv[1];
  nChosenProc = atoi(argv[2]);
  nChosenRep  = atoi(argv[3]);

  if(atoi(argv[4])) bLoadData = true;
  else              bLoadData = false;

  if(atoi(argv[5])) bCrossV = true;
  else              bCrossV = false;

  if(bPriors)
    {
      fMeanPrior = atof(argv[6]);
      afVarsPrior[0] = atof(argv[7]);
      afVarsPrior[1] = atof(argv[8]);
      afVarsPrior[2] = atof(argv[9]);
      
      cout << "LPD with prior P(s) ~ exp(" << afVarsPrior[0] << "/(s^2) + " << afVarsPrior[1] << "/s + " << afVarsPrior[2] << "*log(s))" << endl;
    }
  else
    {
      cout << "LPD with uniform Prior" << endl;
    }
  /* Initilialise pseudo random numbers with current time, 
   * this allows sucessive cross validations to run on a different 
   * subset of samples and variable initilizations to be different */
  int nTimeSeed = time(0);
  srand(nTimeSeed);

  /* File containing info about this run */
  ofstream file;

  file.open("Info.txt");
  file << szTrainFile << endl;
  file << "Time Seed " << nTimeSeed << endl;
  file << "Reps " << nChosenRep << endl;
  file << "Proc " << nChosenProc << endl;
  if(bPriors)
    {
      file << "Priors" << endl;
      file << fMeanPrior << endl;
      file << afVarsPrior[0] << endl;
      file << afVarsPrior[1] << endl;
      file << afVarsPrior[2] << endl;
    }
  file.close();
  /* ------------- */

  /* Create objects */
  pData = new c_LDAData(szTrainFile, nChosenProc, nChosenRep);
  pLDA = new c_LDA(pData, bPriors, fMeanPrior, afVarsPrior);
 
  if(bCrossV)
    {
      for(int c=0; c<10; c++)
	{
	  int nMin = c*pData->nTestSample;
	  int nMax = MIN((c + 1) * pData->nTestSample - 1, pData->nOriginalSample-1);

	  cout << "Cross-Validation number " << c+1 << ", Leaving Out Random " << nMax-nMin << endl;
	  
	  int nTest = 0;
	  int nSamp = 0;
	  for(int i=0; i<pData->nOriginalSample; i++)
	    {
	      if(i < nMin) 
		{
		  /* This is a training sample */
		  pData->apcSample[nSamp++] = pData->apcOriginalSample[pData->anPermutation[i]];
		}
	      else if(i <= nMax) 
		{
		  /* This is a validation sample */
		  pData->apcTestSample[nTest++] = pData->apcOriginalSample[pData->anPermutation[i]];
		}
	      else 
		{
		  /* This is a training sample */
		  pData->apcSample[nSamp++] = pData->apcOriginalSample[pData->anPermutation[i]];
		}
	      pData->nTestSample = nTest;
	    }
	  /* Initialise variables to random values */
	  pLDA->InitialiseValues(pData);
	  /* Initiliase means and vars */
	  pData->InitialiseData();
	  /* Do a k-means clustering */
	  pLDA->InitialiseKMeans(pData, 1);
	  /* Run LPD */
	  pLDA->DoLPD(pData);
	  /* Output results */
	  pLDA->OutputInfo(pData);      
	}
    }
  else
    {
      cout << "Running on the whole data set, likelihood will be the average across all training data" << endl;
      
      /* Set all training and validation samples to the whole data set. This means the Likelihood is over the whole set.*/
      for(int i=0; i<pData->nOriginalSample; i++)
	{
	  pData->apcSample[i] = pData->apcOriginalSample[i];
	  pData->apcTestSample[i] = pData->apcOriginalSample[i];
	}
      pData->nSample = pData->nOriginalSample;
      pData->nTestSample = pData->nOriginalSample;

      /* Load variables if continuing a run */
      if(bLoadData)
	{
	  cout << "Loading Data..." << endl;
	  pLDA->LoadData(pData);
	  pData->LoadData();
	}
      else
	{
	  /* Initialise variables to random values */
	  pLDA->InitialiseValues(pData);
	  /* Initiliase means and vars */
	  pData->InitialiseData();
	  /* Do a k-means clustering */
	  pLDA->InitialiseKMeans(pData, 1);
	}
      /* Run LPD */
      pLDA->DoLPD(pData);
      /* Output results */
      pLDA->OutputInfo(pData);      
    }

  delete pLDA;
  delete pData;
  if(afVarsPrior) delete [] afVarsPrior;

  return 1;
}
