#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <fstream.h>
#include <iostream.h>
#include "gfns.h"

#define PI 3.141592654
#define SMALL_NUMBER 1e-30
#define MIN_VARIANCE 1e-5
#define BIG_NUMBER   1e21

#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))
#define NMAXFEAT 13

/* Sample.cpp */
class c_LDASample
{
public:
  int       nGenes;     /* Number of Genes in each sample */
  int       nProcess;   /* Overall number of processes*/
  int       nId;        /* Original ID in the data */

  double  *afData;      /* nGenes */
  bool    *abData;      /* true if data is available (i.e. > -9999) */

  double  **aafPhi;     /* nGenes x nProcess, Gene specific Discrete (i.e. Multinomial over processes) - Latent Variable */
  double   *afGamma;    /* nProcess, Sample specific Dirichlet Parameter - Latent Variable */

  c_LDASample(int nCurrentGenes, ifstream *pDataFile, int nCurrentProcess);
  ~c_LDASample();

  void SmoothPhi();
  void SmoothGamma();

  void InitialiseSample();

  void NormalisePhi();
};

class c_LDAData
{
 public:
  c_LDASample **apcSample;          /* These are just pointers */
  c_LDASample **apcTestSample;      /* These are just pointers */
  c_LDASample **apcOriginalSample;  /* Sample classes - these contain data */
  int          *anPermutation;      /* Permutation */ 
  int           nSample;            /* Number of examples used in parameter estimation phase */
  int           nTestSample;        /* Number of examples used in cross validation */
  int           nOriginalSample;    /* Total number of examples */
  int           nGenes;             /* Number of features (rows) in each sample aafData */
  /* Options */
  int nProcess;                     /* Equivalent to K - number of processes */
  int nReps;                        /* Repititions of the gradient ascent */

  c_LDAData(char *szFileName, int nProcess, int nReps);
  ~c_LDAData();

  void SmoothPhi();
  void SmoothGamma();

  void NormalisePhi();
  
  void InitialiseData();

  void LoadData();
};

class c_LDA
{
 public:
  int       nGenes;      /* Total number of genes available */  
  int       nSample;     /* Total number of samples */
  int       nProcess;    /* Number of processes chosen */

  bool      bPriors;    /* true if we want to use the priors */
  
  double  fLL;          /* Log Likelihood - not guaranteed to be current */

  double  fMeanPrior;   /* Prior for the variance of the normal mean prior - 'mean' of mean is 0 */
  double *afVarsPrior;  /* Priors for the variance */

  double  **aafMeans;   /* nGenes x nProcess, Mean of gaussian for each gene and process */
  double  **aafVars;    /* nGenes x nProcess, Variance of gaussian for each gene and process */

  double   *afAlpha;    /* nProcess, Dirichlet Parameter */

  void      UpdateGamma(c_LDAData *pData);
  void      UpdateIndividualGamma(c_LDASample *pSample);

  void      UpdateAlpha(c_LDAData *pData);

  void      UpdatePhi(c_LDAData *pData);
  void      UpdateIndividualPhi(c_LDASample *pSample);

  void      UpdateLambda(c_LDAData *pData);

  void      UpdateMean(c_LDAData *pData);
  void      UpdateVars(c_LDAData *pData);

  c_LDA(c_LDAData *pcData, bool bPriors, double fMeanP, double *afVarsP);
  ~c_LDA();

  void   LoadData(c_LDAData *pData);

  double ELogThetaGamma(int nTerm, int nCurrentProcess, c_LDAData *pData);

  void DoLPD(c_LDAData *pData);

  void OutputInfo(c_LDAData *pData);
  void SmoothVars(c_LDAData *pData);
  void SmoothAlpha(c_LDAData *pData);

  void InitialiseKMeans(c_LDAData *pData, int nType);

  void Norm_Pdf_Parts(double **pafExpArgs, double **pafDenom, int k, c_LDASample *pSample);
  void Norm_Pdf(double *pfValue, c_LDASample *pSample, int nCurrentProcess, int nCurrentGene);

  void InitialiseValues(c_LDAData *pData);

  double LogLikelihood(c_LDAData *pData);
  double Bound(c_LDAData *pData);
};

class c_KMeans
{
 public:
  int      nFeat;
  int      nCenters;
  double **aafCenters;

  c_KMeans(int nProcess, int nDFeat);
  ~c_KMeans();

  void CalcDist(double *afFeats, bool *abFeats, int k, double *pfDist);
  void UpdateMembership(c_LDAData *pData, int nType);
  void UpdateCenters(c_LDAData *pData, int nType);
  int  nFindNearestCenter(double *afFeats, bool *abFeats);
};

/* allocate.cpp */
void nAllocateArray(int ***paanA, int nD1, int nD2);
void nAllocateArray(double ***paafA, int nD1, int nD2);
void nAllocateArray(double ****paaafA, int nD1, int nD2, int nD3);
void nAllocateArray(double *****paaaafA, int nD1, int nD2, int nD3, int nD4);
void nFreeArray(int ***paanA, int nD1);
void nFreeArray(double ***paafA, int nD1);
void nFreeArray(double ****paaafA, int nD1, int nD2);
void nFreeArray(double *****paaaafA, int nD1, int nD2, int nD3);
