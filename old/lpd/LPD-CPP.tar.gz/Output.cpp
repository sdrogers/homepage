#include "Main.h"

/* This outputs all the variables to textfiles */
void c_LDA::OutputInfo(c_LDAData *pData)
{
  ofstream file;
  
  file.open("Means.txt");
  for(int g=0; g<pData->nGenes; g++) 
    {
      for(int k=0; k<pData->nProcess; k++) file << aafMeans[g][k] << " ";
      file << endl;
    }
  file.close();


  file.open("Vars.txt");
  for(int g=0; g<pData->nGenes; g++) 
    {
      for(int k=0; k<pData->nProcess; k++) file << aafVars[g][k] << " ";
      file << endl;
    }
  file.close();

  file.open("Gamma.txt");
  for(int i=0; i<pData->nSample; i++) 
    {
      double fSum = 0.0;
      for(int k=0; k<pData->nProcess; k++) file << pData->apcSample[i]->afGamma[k] << " ";
      file << endl;
    }
  file.close();

  file.open("Phi.txt");
  for(int i=0; i<pData->nSample; i++)
    {
      for(int g=0; g<pData->apcSample[i]->nGenes; g++) 
	{	
	  for(int k=0; k<pData->nProcess; k++) file <<  pData->apcSample[i]->aafPhi[g][k] << " ";
	  file<< endl;
	}
      file << endl;
    }
  file.close();


  file.open("Alpha.txt");
  for(int k=0; k<pData->nProcess; k++) file <<  afAlpha[k] << " ";
  file << endl << endl;
  file.close();

  file.open("PermTrain.txt");
  for(int i=0; i<pData->nSample; i++) file << pData->apcSample[i]->nId << " ";
  file << endl << endl;
  file.close();

  file.open("PermTest.txt");
  for(int i=0; i<pData->nTestSample; i++) file << pData->apcTestSample[i]->nId << " ";
  file << endl << endl;
  file.close();

  file.open("LogLikelihood.txt", ofstream::app);
  file << this->nProcess << " " << this->fLL << endl;
  //file << this->afVarsPrior[0] << " " << this->fLL << endl;
  file.close();
}

