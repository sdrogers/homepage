#include "Main.h"

/* Prevent Alpha and the Variances from dropping to a very low level, with a prior on the variance this isnt an issue*/
void c_LDA::SmoothAlpha(c_LDAData *pData)
{
  /* alpha cannot go below zero as it is the dirichlet parameter...*/
  for(int k=0; k<pData->nProcess; k++) if(afAlpha[k] < 0) 
    {
      for(int k1=0; k1<pData->nProcess; k1++)afAlpha[k1] = 1.0;
      break;
    }
  /* If the hessian is ill conditioned then alpha can go out of control...*/
  for(int k=0; k<pData->nProcess; k++) if(afAlpha[k] > 50) 
    {
      for(int k1=0; k1<pData->nProcess; k1++)afAlpha[k1] = 1.0;
      break;
    }
}

void c_LDA::SmoothVars(c_LDAData *pData)
{
  for(int g=0; g<pData->nGenes; g++)
    {
      for(int k=0; k<pData->nProcess; k++)
	{
	  if(aafVars[g][k] < MIN_VARIANCE) aafVars[g][k] = MIN_VARIANCE;
	}
    }
}

