/* General functions to allocate, initialise and free arrays */
void nAllocateArray(int ***paanA, int nD1, int nD2)
{
  (*paanA) = new int*[nD1];
  for(int i=0; i<nD1; i++) (*paanA)[i] = new int[nD2];
  for(int i=0; i<nD1; i++) for(int j=0; j<nD2; j++) (*paanA)[i][j] = 0; 
}

void nAllocateArray(double ***paafA, int nD1, int nD2)
{
  (*paafA) = new double*[nD1];
  for(int i=0; i<nD1; i++) (*paafA)[i] = new double[nD2];
  for(int i=0; i<nD1; i++) for(int j=0; j<nD2; j++) (*paafA)[i][j] = 0.0; 
}
 
void nAllocateArray(double ****paaafA, int nD1, int nD2, int nD3)
{
  (*paaafA) = new double**[nD1];
  for(int i=0; i<nD1; i++) nAllocateArray(&((*paaafA)[i]), nD2, nD3);
}

void nAllocateArray(double *****paaaafA, int nD1, int nD2, int nD3, int nD4)
{
  (*paaaafA) = new double***[nD1];
  for(int i=0; i<nD1; i++) nAllocateArray(&((*paaaafA)[i]), nD2, nD3, nD4);
}

void nFreeArray(int ***paanA, int nD1)
{
  for(int i=0; i<nD1; i++) delete [] (*paanA)[i];
  delete [] (*paanA);
}

void nFreeArray(double ***paafA, int nD1)
{
  for(int i=0; i<nD1; i++) delete [] (*paafA)[i];
  delete [] (*paafA);
}

void nFreeArray(double ****paaafA, int nD1, int nD2)
{
  for(int i=0; i<nD1; i++) 
  {  
    for(int j=0; j<nD2; j++) delete [] (*paaafA)[i][j];
    delete [] (*paaafA)[i];
  }
  delete [] (*paaafA);
}

void nFreeArray(double *****paaaafA, int nD1, int nD2, int nD3)
{
  for(int i=0; i<nD1; i++) 
  {  
    nFreeArray(&((*paaaafA)[i]), nD2, nD3);
  }
}
