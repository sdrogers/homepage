class GFNS
{
 public:
  double digamma(double x);
  double digamms(double x);
  double trigamma(double x);
  double trigamms(double x);
  double polygamma(double x, int order);
  double gamrnd(double A);
  double gamrnd_int(int a);
  double gammalog(double x);
  GFNS();
};
