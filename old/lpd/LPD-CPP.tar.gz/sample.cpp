#include "Main.h"

void c_LDASample::InitialiseSample()
{
  /* Gamma is Random */
  for(int k=0; k<nProcess; k++) afGamma[k] = 10 * (static_cast<double>(rand())/static_cast<double>(RAND_MAX)); 
  SmoothGamma();
  /* Phi Random */
  for(int g=0; g<nGenes; g++) for(int k=0; k<nProcess; k++) aafPhi[g][k] = 0.1 * (static_cast<double>(rand())/static_cast<double>(RAND_MAX));
  NormalisePhi();
}

c_LDASample::c_LDASample(int nCurrentGenes, ifstream *pDataFile, int nTotalProcess)
{
  /* Training Constructor */
  nGenes   = nCurrentGenes;
  nProcess = nTotalProcess;

  afData = new double[nGenes];
  abData = new bool[nGenes];

  /* Read Data from file */
  for(int g=0; g<nGenes; g++) 
    {
      /* by default levels below -9000 are taken as missing */
      *pDataFile >> afData[g];
      if(afData[g] > -9000) 
	abData[g] = true;
      else 
	abData[g] = false;
    }

  nAllocateArray(&aafPhi, nGenes, nProcess);

  afGamma = new double[nProcess];

  /* Initialise Data */
  /* Gamma Random */
  InitialiseSample();
}

c_LDASample::~c_LDASample()
{
  delete [] afData;
  delete [] abData;
  nFreeArray(&(this->aafPhi), this->nGenes);
  delete [] afGamma;
}

void c_LDASample::SmoothGamma()
{
  for(int k=0; k<nProcess; k++)
    {
      if(afGamma[k] < SMALL_NUMBER) afGamma[k] = SMALL_NUMBER;
    }
}

void c_LDASample::SmoothPhi()
{
  for(int g=0; g<nGenes; g++)
    {
      for(int k=0; k<nProcess; k++)
	{
	  if(aafPhi[g][k] < SMALL_NUMBER) aafPhi[g][k] = SMALL_NUMBER;
	}
    }
}

void c_LDASample::NormalisePhi()
{
  /* Normalise over the 2nd dimension */

  for(int g=0; g<nGenes; g++)
    {
      double fSumPhi = 0.0;

      for(int k=0; k<nProcess; k++) if(this->abData[g]) fSumPhi += aafPhi[g][k];
      if(isinf(fSumPhi))
	    cout << "Inf SumPhi" << endl;	
      for(int k=0; k<nProcess; k++) if(this->abData[g]) 
	{
	  aafPhi[g][k] /= fSumPhi;
	  if(isnan(aafPhi[g][k]))
	    cout << "NaN Phi" << endl;
	}
    }
}
