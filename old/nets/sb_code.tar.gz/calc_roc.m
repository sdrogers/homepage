function [cspec, sens] = calc_roc(actual, W, range)

L = length(range);
cspec = zeros(L,1);
sens = zeros(L,1);

actual = abs(actual);
W = abs(W);

for l = 1:L
    Wa = (W>range(l));
    tp = sum(sum(Wa.*actual));
    tn = sum(sum((1-Wa).*(1-actual)));
    fp = sum(sum(Wa.*(1-actual)));
    fn = sum(sum((1-Wa).*actual));
    sens(l) = tp/(tp+fn);
    cspec(l) = fp/(tn+fp);
end