%Sparse Bayesian Inference
%------------------------------------------------------------------
% A Bayesian Regression Approach to the Inference of Regulatory Networks
% from Gene Expression Data
%
%Simon Rogers and Mark Girolami
%Bioinformatics Research Centre, University of Glasgow
%srogers@dcs.gla.ac.uk
%http://www.dcs.gla.ac.uk/~srogers/reg_nets.html
%
%RVMW = cause_rvm_approach(d,ko,Sigma)
%INPUTS
%d - unnormalised data i.e. dun from create_data
%ko - list of knockout experiments for the data
%Sigma - proportion of variance(e) to use as \sigma^2 in Sparse Bayes
%algorithm...always set to 1
%
%OUTPUTS
%RVMW - (M+1 x M) matrix of weights from.  (extra row is from bias).  Each
%column corresponds to weights IN to gene
%
function RVMW = cause_rvm_approach(d,ko,Sigma)


[M,R,K] = size(d);
X = reshape(d,M,R*K);
%normalise each gene
m = mean(X,2);
X = X - repmat(m,1,R*K);
V = var(X')';
X = X./repmat(sqrt(V),1,R*K);

%set up weight matrix
RVMW = zeros(M+1,M);

%loop through genes
for i = 1:M
    y = X(i,:)';
    v = var(y);
    x = X;
    x(i,:) = [];
    %remove the knockouts of this gene
    if sum(ko==i)>0
        p = find(ko==i);    
        ra = R*(p-1)+1:R*p;
        y(ra) = [];
        x(:,ra) = [];
    end
    %Call Sparse Bayes algorithm
    fprintf('Inferring weights into gene %g\n',i);
    [Mu,Sig,used] = rvm_regression(x',y,'none',1,1,0,Sigma*v);
    RVMW([1:i-1 i+1:end],i) = Mu;
end
