function [p,h] = comp_roc_plot(cspec1,sens1,cspec2,sens2,p)
%Generates ROC curve from comp. spec and sensitivity

if exist('p')
	figure(p);
	hold on;
else
	p=figure;
end

if size(cspec1,1)>size(cspec1,2)
    cspec1 = cspec1';
    sens1 = sens1';
end
if size(cspec2,1)>size(cspec2,2)
    cspec2 = cspec2';
    sens2 = sens2';
end


cspec1 = [1 cspec1 0 1 1];
sens1 = [1 sens1 0 0 1];
cspec2 = [1 cspec2 0 1 1];
sens2 = [1 sens2 0 0 1];

h = plot(cspec1,sens1,'k','linewidth',2);
hold on;
plot(cspec2,sens2,'k--','linewidth',2);

plot([0 1],[0 1],'k--');
xlabel('Complementary Specificity (FP/(TN+FP))');
ylabel('Sensitivity (TP/(TP+FN))');
