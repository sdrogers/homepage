%Data Creator
%------------------------------------------------------------------
% A Bayesian Regression Approach to the Inference of Regulatory Networks
% from Gene Expression Data
%
%Simon Rogers and Mark Girolami
%Bioinformatics Research Centre, University of Glasgow
%srogers@dcs.gla.ac.uk
%http://www.dcs.gla.ac.uk/~srogers/reg_nets.html
%
%[d, connectivity, W, Corr, RVMW, dun] = create_data(M,ko,R,Noise,fname,pars,con)
%INPUTS
%M - Number of Genes (nodes)
%ko - list of knockout experiments - normally [1:M]
%R - Number of repetitions for each experiment
%Noise - level of noise in the generation process
%fname - name of output network file for use with Pajek
%pars - [optional] Structure containing SDE parameters
%con - [optionsl] Connectivity matrix - if not supplied, will be created
%
%OUTPUTS
%d - data, M x 2*R x length(ko) array.  Normalised in manner of Rice et al
%connectivity - connectivity matrix.  Each column, i, corresponds to the
%connections out of gene i
%W - Least squares solution on Rice normalised data
%Corr - Correlations
%RVMW - weights for RVM trained using RICE data
%dun - un-normalised data, M x 2*R x length(ko) array
%
%
%
%NOTE - W and RVMW are for interest only and do not correspond to results
%quoted in the paper.
function [d, connectivity, W, Corr, RVMW, dun] = create_data(M,ko,R,Noise,fname,pars,con)
%random initialisation
if ~exist('con')
    fprintf('\nMaking Network...');
    connectivity = make_network(M,1,5,2.5,0.5);
else
    connectivity = con;
end
Sf = 100; %Sampling freq
%Create the pajek graph file
create_pajek_graph(connectivity',fname);

%create empty data matrix
d = zeros(M,R*2,length(ko));

%Create parameters structure if it does not exist
if ~exist('pars')
    G = 1;B = 1;A = 0.5;L = 1;
else
    G = pars.G;
    B = pars.B;
    A = pars.A;
    L = pars.L;
end


%First, without any knockouts

%Initial conditions
y=zeros(M,1);
fprintf('\nIntegrating SDE...');
[Y,T] = euler_forward(30,y,connectivity,G,B,A,L,Noise,[]);
for nko = 1:length(ko)
    d(:,1:R,nko) = Y(end-(R*Sf)+1:Sf:end,:)';
end

%Now, knockouts
for nko = 1:length(ko)
    %loop through the knockouts
    cko = connectivity;
    cko(ko(nko),:) = zeros(1,M);
    cko(:,ko(nko)) = zeros(M,1);
    y=zeros(M,1);
    [Y,T] = euler_forward(30,y,cko,G,B,A,L,Noise,ko(nko));
    d(:,R+1:end,nko) = Y(end-(R*Sf)+1:Sf:end,:)';
end
%store un-normalised data
dun = d;
%normalise it all in the style of Rice
for i = 1:length(ko)
    a = mean(d(:,:,i),2);
    d(:,:,i) = d(:,:,i) - repmat(a,1,R*2);
    v = var(d(:,:,i)')';
    d(:,:,i) = d(:,:,i)./repmat(sqrt(v),1,R*2);
end

%Make empty connection matrices
W = zeros(M);%Least Squares - not quoted in results
RVMW = zeros(M);%RVM on Rice data - not quoted
Corr = zeros(M);%Correlation
[W, RVMW, Corr] = do_experiments(d,M,ko,R);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [W, RVMW, Corr] = do_experiments(d,N,ko,R)
%Get least squares solution
W = zeros(N);
Corr = zeros(N);
RVMW = zeros(N+1,N);

%Least Squares - with 0.01 regulariser - uncomment if required
%for i = 1:length(ko)
%    X = d(:,:,i);
%    y = X(ko(i),:)';
%    X(ko(i),:) = [];
%    W([1:ko(i)-1 ko(i)+1:end],i) = pinv(X*X' + 0.01*eye(N-1))*X*y;
%end

%Correlations
for i = 1:length(ko)
    %find correlations between all genes and knocked out gene
    for n = 1:N
       if ko(i)~=n
           x = d(ko(i),:,i);
           y = d(n,:,i);
           num = (2*R)*sum(x.*y) - sum(x)*sum(y);
           den = sqrt(((2*R*sum(x.^2))-(sum(x)^2))*((2*R*sum(y.^2))-sum(y)^2));
           Corr(n,i) = num/den;
       end
    end
end

%RVM on each experiment - NOT same as published results - uncomment if
%required
%for i = 1:length(ko)    
%    X = d(:,:,i);
%    y = X(ko(i),:)';
%    X(ko(i),:) = [];
%    X = X';
%    nodisplay = 0;
%    fprintf('Training RVM %g\n',i);
%    [Mu,Sig,used] = rvm_regression(X,y,'none',1,1,nodisplay,0.5*var(y));
%    RVMW([1:ko(i)-1 ko(i)+1:end],i) = Mu;
%end