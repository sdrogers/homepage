function create_pajek_graph(A,fname)
%As=sparse(A);
[i j k]=find(A);
L=length(i);
fid=fopen(fname,'w');
fprintf(fid,'*VERTICES %d\n', length(A));
fprintf(fid,'*ARCS\n');
for n=1:L
    fprintf(fid,'%d %d %6.8f\n',i(n),j(n),k(n));
end
fclose(fid);