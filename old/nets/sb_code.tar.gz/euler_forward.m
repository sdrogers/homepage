function [y, t] = euler_forward(T,Yo,conn,G,B,A,L,Noise,ko)
%Euler, Marayama approach to integrate SDE's
dt = 0.01;
t = 0:dt:T;
M = length(Yo);
y = zeros(length(t),M);
y(1,:) = Yo';

%Make Brownian Path
Le = length(t);
R = 1;
delt = dt/R;
W = sqrt(delt)*Noise*randn(M,Le*R);
W = cumsum(W')';
for i = 2:length(t);
    dydt = odefun(t(i),y(i-1,:)',conn,G,B,A,L,ko);
    %dydt = dydt + randn(10,1)*0.1;
    y(i,:) = y(i-1,:) + dt*dydt' + (W(:,R*i)-W(:,R*(i-1)))';
    y(i,ko) = 0;
end