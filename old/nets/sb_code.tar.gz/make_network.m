%Network Creator
%------------------------------------------------------------------
% A Bayesian Regression Approach to the Inference of Regulatory Networks
% from Gene Expression Data
%
%Simon Rogers and Mark Girolami
%Bioinformatics Research Centre, University of Glasgow
%srogers@dcs.gla.ac.uk
%http://www.dcs.gla.ac.uk/~srogers/reg_nets.html
%
%connectivity = make_network(N,ODmin,ODmax,nab,pex)
%INPUTS
%M - Number of Genes (nodes)
%ODmin - minimum number of connections out from a gene
%ODmax - maximum number of connections out from a gene
%nab - power law parameter - 2.5
%pex - probability any given connection is excitatory - 0.5
%
%OUTPUTS
%connectivity - M x M connectivity matrix.  Each column, i, corresponds to the
%connections out of gene i
%
%
function connectivity = make_network(M,ODmin,ODmax,nab,pex)


R = ODmax -ODmin + 1;
p = zeros(R,1);

%Calculate un-normalised probabilities
for r = 1:R
    p(r) = (r+ODmin-1)^(-nab);
end

%Normalise
p = p./sum(p);

connectivity = zeros(M);

for n = 1:M
    %make a column for outputs from each gene
    noC = sample_from_mult(p);    
    ok = 0;
    while ok == 0
        a = randperm(M);
        if sum(a(1:noC)==n)>0
            ok = 0;
        else
            ok = 1;
        end
    end
    for c = 1:noC
        in = rand;
        if in>=pex
            connectivity(a(c),n) = 1;
        else
            connectivity(a(c),n) = -1;
        end
    end
end

%--------------------------------
function o = sample_from_mult(p)
%Generates a sample from a multinomial distribution with probabilities p

Np = length(p);
c = cumsum(p);

a = rand;
i = 1;
while a > c(i)
    i = i+1;
end
o = i;