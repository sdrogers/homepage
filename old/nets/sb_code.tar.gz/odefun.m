function yo = odefun(t,y,conn,G,B,A,L,ko)

%conn - rows show inputs to genes - 1/0/-1 for excite, none, inhib

M = size(y,1);

ex = (conn==1);
in = (conn==-1);

yo = repmat(A,M,1)+ex*(y.^G);
yo = yo./(1 + ex*(y.^G) + in*(y.^B));
yo = yo - L*y;

yo(ko) = 0;