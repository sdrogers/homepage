function [Mu, Sig, used, c] = rvm_regression(data,t,ktype,kpar,bias,display,Sigma)

warning off
[N,M] = size(data);
%Create Kernel
switch ktype
    case 'none'
        K = data;
    otherwise
        K = kernel(data,data,ktype,kpar);
        M = N;
end
%add bias if required
if bias == 1
    K = [K ones(N,1)];
    M = M + 1;
end

MAX_IT = M*20;

%initalise used
used = ceil(rand*M);
%used = M;
Alpha = repmat(inf,M,1);
if ~exist('Sigma')
    Sigma = var(t)*0.5;%holds VARIANCE
end
%Initialise params

phi_in = K(:,used);
Alpha(used) = (sum(phi_in.^2))/(((sum((phi_in'*t).^2))/(sum(phi_in.^2)))-Sigma);
Alpha_change = repmat(Inf,M,1);
Lall = [];

tried = zeros(M,1);
tried(used) = 1;
for it = 1:MAX_IT
    %Calculate C
    Alpha(find(Alpha<1e-10))=1e-10;
    C = Sigma*eye(N) + phi_in * (diag(1./Alpha(used))) * phi_in';
    if any(isnan(C))
        fprintf('NAN');
        Sigma
        Alpha(used)
    end
    if any(isinf(C))
        fprintf('INF');
        Sigma
        Alpha(used)
    end
    Ci = pinv(C);
    %Calculate marginal
    L = -0.5*(N*log(2*pi)+log(det(C))+ t'*Ci*t);
    Lall = [Lall;L];
    
    %Choose a basis vector
    b = ceil(rand*M);
    non_used = find(tried==0);
    b = non_used(ceil(rand*length(non_used)));
    tried(b) = 1;
    
    if sum(tried==0) == 0
        tried = zeros(M,1);
    end
    
    S = K(:,b)'*Ci*K(:,b);
    Q = K(:,b)'*Ci*t;
    
    if sum(used==b)>0
        %Basis is currently IN
        s = (Alpha(b)*S)/(Alpha(b)-S);
        q = (Alpha(b)*Q)/(Alpha(b)-S);
    else
        %Basis is currently OUT
        s = S;
        q = Q;
    end
    Theta = q^2-s;
    if Theta>0
        if sum(used==b)>0
            Aold = Alpha(b);
            Alpha(b) = (s^2)/(q^2-s);    
            Alpha_change(b) = abs(Aold-Alpha(b));
        else
            Aold = Alpha(b);
            Alpha(b) = (s^2)/(q^2-s);
            Alpha_change(b) = abs(Aold-Alpha(b));
            used = [used;b];
            phi_in = [phi_in K(:,b)];
        end
    else
        if sum(used==b)>0 & length(used)>1 % can't remove last one
           %Delete basis
           pos = find(used==b);
           used(pos) = [];
           phi_in(:,pos) = [];
           Alpha(b) = Inf;
           Alpha_change(b) = Inf;
        else
            %Do nothing!
            Alpha_change(b) = 0;
        end
    end
    Mu = zeros(M,1);
    Sig = zeros(M);
    Sig(used,used) = pinv(diag(Alpha(used)) + (1/Sigma)*phi_in'*phi_in);
    Mu(used) = (1/Sigma)*Sig(used,used)*phi_in'*t;
    %Update Sigma
    if length(used) == 0
        fprintf('\n\nNothing Left\n\n');
    end
    %Sigma = sum((t-phi_in*Mu(used)).^2)/N;%/(sum(diag(diag(Alpha(used)).*Sig(used,used))));
    if Sigma<1e-20
        Sigma = 1e-20;%preserve numerical stability
    end
    if display == 1 & rem(it,2) == 0
        fprintf('Iteration %g, Marginal %g, no basis in %g, max A change %g\n',it,L,length(used),max(Alpha_change));
    end
    if max(Alpha_change)<1
        break;
    end
end

warning on
