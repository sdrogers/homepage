%Simple Script
%------------------------------------------------------------------
% A Bayesian Regression Approach to the Inference of Regulatory Networks
% from Gene Expression Data
%
%Simon Rogers and Mark Girolami
%Bioinformatics Research Centre, University of Glasgow
%srogers@dcs.gla.ac.uk
%http://www.dcs.gla.ac.uk/~srogers/reg_nets.html
%
%
%This script creates one network, samples data from it and generates the
%connections from Correlation and Sparse Bayes
%
%

fprintf('A Bayesian Regression Approach to the Inference of Regulatory Networks from Gene Expression Data\n\n');
fprintf('Simon Rogers and Mark Girolami\nBioinformatics Research Centre, University of Glasgow\n');
fprintf('srogers@dcs.gla.ac.uk\nhttp://www.dcs.gla.ac.uk/~srogers/reg_nets.html\n');
M = 30; %Number of Genes
Epsilon = 0.01; %Noise
R = 2; %Number of repetitions
pars.A = 0.5;%Alpha
pars.L = 1;%Lambda
pars.G = 1;%Gamma
pars.B = 1;%Beta

ko = [1:30];%List of knockouts to perform

fprintf('\n\nCreating Data...');
[d, connectivity, W, Corr, RVMW, dun] = create_data(M,ko,R,Epsilon,'example.net',pars);
clear RVMW;
%display data
[M,aR,K] = size(dun);
A = reshape(dun,M,aR*K);
a = mean(A,2);
A = A - repmat(a,1,size(A,2));
s = std(A')';
A = A./repmat(s,1,size(A,2));
p=figure;imagesc(A);colorbar;drawnow;
fprintf('\n\nData created (shown in figure %g)...\n\n',p);
fprintf('\n\nSparse Bayes Approach...\n\n');
RVMW = cause_rvm_approach(dun,ko,1);
p=figure;imagesc(connectivity);colorbar;title('True Connectivity');
fprintf('\n\nFigure %g shows true connectivity - each column is connections out of a gene',p);
p=figure;imagesc(Corr);colorbar;title('Correlation Connectivity');
fprintf('\nFigure %g shows correlation connectivity - each column is connections out of a gene',p);
p=figure;imagesc(RVMW(1:end-1,:)');colorbar;title('Sparse Bayes Connectivity');
fprintf('\nFigure %g shows Sparse Bayes connectivity - each column is connections out of a gene',p);
drawnow;

%Create ROC plots
[cspec, sens] = calc_roc(connectivity, Corr, [0:0.01:1]);
[cspecr,sensr] = calc_roc(connectivity,RVMW(1:end-1,:)',[0:0.01:1]);
comp_roc_plot(cspecr,sensr,cspec,sens);
legend('Sparse Bayes','Correlation');

fprintf('\n\nSparse Bayes - sensitivity %f, complimentary specificity %f\n',sensr(1),cspecr(1));
fprintf('\n\nScript finished...');