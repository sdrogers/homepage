//MMSampler.h
#include <fstream.h>
#include <iostream.h>
using std::fixed;
using std::scientific;
#include <ctime>
#include <cmath>
#include "prior.h"
#include "etaprior.h"
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
class MMSampler {
	public:
		MMSampler(int nGin,int nDin,int *nTin,int *nEin);
		~MMSampler();
		void init2(char *fname);
		void displayPars();
		void sample(int NSample,int NSwap,int opt,double **R,double **Rsq, double **etaR,double **etaRsq);
		void sample(int NSample,int NSwap,char *SampName, char *EtaName,int opt,double **R,double **Rsq, double **etaR,double **etaRsq);
		void displaySettings();
		void setseed(long sval);
		void setstatus(char *fname);
		void writeE(char *fname);
		void sampleData();
	private:
		int nG;
		int nD;
		int *nT;
		int *nE;
		int nVarS;
		int act;
		int Mu0Vals;
		prior **priors;
		etaprior *etapriors;
		prior *Mu0Priors;
		prior noiseprior;
		double ****E;
		double **pars;
		double **T;
		double **eta;
		double *OldPosts;
		double **oldEta;
		int **etafix;
		double ***Mu;
		double ***oldMu;
		double *Mu0Cand;
		double *Posts;
		double Post;
		double *noiseVar;
		double JustLike;
		double **IndLike;
		double **OldIndLike;
		double **Cand;
		double **etaCand;
		double *OldPars;
		double noiseCand;
		gsl_rng *r;
		double calcNLN(int g);
		int sampleGene(int g);
		int sampleEta(int d);
		int sampleNoise();//Does all the noise in one go
		void checkLike();
};
