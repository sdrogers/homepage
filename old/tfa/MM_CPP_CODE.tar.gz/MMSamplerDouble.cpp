//MMSampler.cpp
//This is the re-parameterised version - double, for two separate datasets
#include "MMSampler.h"

MMSampler::MMSampler(int NGenesin,int nDin,int *nTin,int *nEin)
{
	nG = NGenesin;
	nD = nDin;
	nT = new int[nD];
	nE = new int[nD];
	for(int d=0;d<nD;d++)
	  {
	    nT[d] = nTin[d];
	    nE[d] = nEin[d];
	  }
	pars = new double*[nG];
	priors = new prior*[nG];
	Cand = new double*[nG];
	IndLike = new double*[nG];
	OldIndLike = new double*[nG];
	for(int g=0;g<nG;g++)
	  {
	    pars[g] = new double[4];
	    priors[g] = new prior[4];
	    Cand[g] = new double[4];
	    IndLike[g] = new double[nD];
	    OldIndLike[g] = new double[nD];
	  }
	Mu0Cand = new double[nG];
	for(int g=0;g<nG;g++)
	  Mu0Cand[g] = 0.01;
	//Generic
	Mu0Priors = new prior[nG];
	OldPosts = new double[nG];
	Posts = new double[nG];
	OldPars = new double[4];
	r = gsl_rng_alloc(gsl_rng_taus);

	E = new double***[nD];

	etapriors = new etaprior[nD];
	for(int d=0;d<nD;d++)
	  etapriors[d].setT(nT[d]-1);

	Mu = new double**[nD];
	oldMu = new double**[nD];
	oldEta = new double*[nD];
	etaCand = new double*[nD];
	eta = new double*[nD];
	T = new double*[nD];
	etafix = new int*[nD];
	for(int d=0;d<nD;d++)
	  {
	    etafix[d] = new int[nT[d]-1];
	    T[d] = new double[nT[d]];
	    eta[d] = new double[nT[d]-1];
	    oldEta[d] = new double[nT[d]-1];
	    etaCand[d] = new double[nT[d]-1];
	    //etapriors[d] = new prior[nT[d]-1];
	    Mu[d] = new double*[nG];
	    oldMu[d] = new double*[nG];
	    E[d] = new double**[nG];
	    for(int g=0;g<nG;g++)
	      {
		Mu[d][g] = new double[nT[d]];
		oldMu[d][g] = new double[nT[d]];
		E[d][g] = new double*[nT[d]];
		for(int t=0;t<nT[d];t++)
		  E[d][g][t] = new double[nE[d]];
	      }
	    
	  }
	

	for(int d=0;d<nD;d++)
	  {
	    for(int t=0;t<nT[d]-1;t++)
	      etaCand[d][t] = 0.1;//Default value
	  }

	act = 1;

  	long seedVAL = time(NULL);
  	gsl_rng_set(r,seedVAL);
	noiseVar = new double[nD];
	for(int d=0;d<nD;d++)
	  noiseVar[d] = 0.001;
	noiseCand = 0.1;
	Mu0Vals = 1;//Default
}

void MMSampler::sample(int NSample,int NSwap,int opt,double **R,double **Rsq,double **etaR,double **etaRsq)
{

  //Little etaprior test
  /*prior *testp = new prior(0,0,10);
  double test=0.0;
  for(int t=0;t<nT[0]-1;t++)
    test += testp->eval(eta[0][t]);
    cout << endl << test << '\t' << etapriors[0].eval(eta[0]);*/

  double *accept = new double[nG+1];
  double *Nsamp = new double[nG+1];
  
  int nP = nG+nD;
  if(nVarS==1)
    nP++;
  for(int g=0;g<nG;g++)
    {
      for(int i=0;i<4;i++)
	{
	  R[g][i] = 0.0;
	  Rsq[g][i] = 0.0;
	}
    }
  for(int d=0;d<nD;d++)
    {
      for(int i=0;i<nT[d]-1;i++)
	{
	  etaR[d][i] = 0.0;
	  etaRsq[d][i] = 0.0;
	}
    }
  for(int i=0;i<nG+1;i++)
    {
      accept[i] = 0.0;
      Nsamp[i] = 0.0;
    }
  double *etaaccept = new double[nD];
  double *etaN = new double[nD];
  for(int d=0;d<nD;d++)
    {
      etaaccept[d] = 0.0;
      etaN[d] = 0.0;
    }
  double noiseaccept = 0.0;
  double noiseN = 0.0;
  int block = 0;
  double ac,mult;
  Post = 0.0;
  JustLike = 0.0;
  for(int i=0;i<nG;i++)
    {
      Posts[i] = calcNLN(i);
      JustLike += Posts[i];
      for(int j=0;j<4;j++)
	Posts[i]+=priors[i][j].eval(pars[i][j]);
      if(Mu0Vals==2)
	{
	  for(int d=0;d<nD;d++)
	    Posts[i]+=Mu0Priors[i].eval(Mu[d][i][0]);
	}
      Post += Posts[i];
    }
  for(int d=0;d<nD;d++)
    {
      //for(int t=0;t<nT[d]-1;t++)
      //Post += etapriors[d][t].eval(eta[d][t]);
      Post += etapriors[d].eval(eta[d]);

      if(nVarS==1)
	Post += noiseprior.eval(noiseVar[d]);
    }
  
  for(int s=0;s<NSample;s++)
    {
      if(opt>0)
	{
	  if(s%opt==0 && s<NSample-1 && s>0)
	    {
	      for(int g=0;g<nG;g++)
		{
		  ac = accept[g]/Nsamp[g];
		  mult = 1.0;
		  if(ac>0.3)
		    mult = 1.5;
		  else if(ac<0.2)
		    mult = 0.5;
		  for(int i=0;i<4;i++)
		    Cand[g][i] = Cand[g][i]*mult;
		  Mu0Cand[g] = Mu0Cand[g]*mult;
		  accept[g] = 0.0;
		  Nsamp[g] = 0.0;
		}

	      for(int d=0;d<nD;d++)
		{
		  ac = etaaccept[d]/etaN[d];
		  for(int t=0;t<nT[d]-1;t++)
		    {
		      if(ac>0.3)
			etaCand[d][t] = 1.5*etaCand[d][t];
		      else if(ac<0.2)
			etaCand[d][t] = 0.5*etaCand[d][t];
		    }
		  etaaccept[d] = 0.0;
		  etaN[d] = 0.0;
		}
	      ac = noiseaccept/noiseN;
	      if(ac>0.3)
		noiseCand = 1.5*noiseCand;
	      else if(ac<0.2)
		noiseCand = 0.5*noiseCand;
	      noiseaccept = 0.0;
	      noiseN = 0.0;
	    }
	}

	if(s%NSwap==0)
	  {
	    //Choose a new block
	    block = gsl_rng_uniform_int(r,nP);
	  }
	if(block<nG)
	  {
	    accept[block] += 1.0*sampleGene(block);
	    Nsamp[block] += 1.0;
	  }
	else if(block>=nG && block<nG+nD)
	  {
	    etaaccept[block-nG] += 1.0*sampleEta(block-nG);
	    etaN[block-nG] += 1.0;
	  }
	else if(block==nG+nD)
	  {
	    noiseaccept += 1.0*sampleNoise();
	    noiseN += 1.0;
	  }

	//Removed max like noise nonsense from here
	//Update R
	for(int g=0;g<nG;g++)
	  {
	    for(int i=0;i<4;i++)
	      {
		R[g][i] += pars[g][i];
		Rsq[g][i] += pow(pars[g][i],2.0);
	      }
	  }
	for(int d=0;d<nD;d++)
	  {
	    for(int t=0;t<nT[d]-1;t++)
	      {
		etaR[d][t] += eta[d][t];
		etaRsq[d][t] += pow(eta[d][t],2.0);
	      }
	  }
    }


	
  /*  cout << endl << "Acceptance Rates: ";
  for(int i=0;i<nG;i++)
    cout << fixed << endl << "Block: " << i << " " << 100.0*accept[i]/Nsamp[i];
  for(int d=0;d<nD;d++)
  cout << endl << "Eta: " << d << " " << 100.0*etaaccept[d]/etaN[d];*/
  delete[] accept;
  delete[] Nsamp;
  
  //Calculate means and variances
  for(int g=0;g<nG;g++)
    {
      for(int i=0;i<4;i++)
	{
	  R[g][i] = R[g][i]/(1.0*NSample);
	  Rsq[g][i] = Rsq[g][i]/(1.0*NSample) - pow(R[g][i],2.0);
	}
    }
  for(int d=0;d<nD;d++)
    {
      for(int t=0;t<nT[d]-1;t++)
	{
	  etaR[d][t] = etaR[d][t]/(1.0*NSample);
	  etaRsq[d][t] = etaRsq[d][t]/(1.0*NSample) - pow(etaR[d][t],2.0);
	}
    }
  if(opt<0)
    {
      for(int g=0;g<nG;g++)
	{
	  for(int i=0;i<4;i++)
	    Cand[g][i] = Rsq[g][i];
	}
      for(int d=0;d<nD;d++)
	{
	  for(int t=0;t<nT[d]-1;t++)
	    etaCand[d][t] = etaRsq[d][t];
	}
    }
  delete[] etaaccept;
  delete[] etaN;
}
void MMSampler::checkLike()
{
  double temp = 0.0;
  for(int d=0;d<nD;d++)
    {
      for(int g=0;g<nG;g++)
	temp += IndLike[g][d];
    }
  cout << -JustLike+temp;
}

void MMSampler::sample(int NSample,int NSwap,char* SampName, char *EtaName,int opt,double **R,double **Rsq,double **etaR,double **etaRsq)
{
	ofstream outFile;
	ofstream outEta;
	ofstream outBlock;
	ofstream noiseFile;
	ofstream postFile;
	ofstream MuFile;
	outFile.open(SampName);
	outEta.open(EtaName);
	EtaName[0] = 'n';
	noiseFile.open(EtaName);
	EtaName[0] = 'l';
	postFile.open(EtaName);
	EtaName[0] = 'b';
	outBlock.open(EtaName);
	EtaName[0] = 'm';
	MuFile.open(EtaName);
	double *accept = new double[nG+1];
	double *Nsamp = new double[nG+1];
	double ***MuM = new double**[nD];
	double ***MuMSq = new double**[nD];

	int nP = nG+nD;
	if(nVarS==1)
		nP++;
	for(int d=0;d<nD;d++)
	  {
	    MuM[d] = new double*[nG];
	    MuMSq[d] = new double*[nG];
	    for(int g=0;g<nG;g++)
	      {
		MuM[d][g] = new double[nT[d]];
		MuMSq[d][g] = new double[nT[d]];

		for(int i=0;i<nT[d];i++)
		  {
		    MuM[d][g][i] = 0.0;
		    MuMSq[d][g][i] = 0.0;
		  }
	      }
	  }
	for(int g=0;g<nG;g++)
	  {
	    for(int i=0;i<4;i++)
	      {
		R[g][i] = 0.0;
		Rsq[g][i] = 0.0;
	      }
	  }
	for(int d=0;d<nD;d++)
	  {
	    for(int i=0;i<nT[d]-1;i++)
	      {
		etaR[d][i] = 0.0;
		etaRsq[d][i] = 0.0;
	      }
	  }
	for(int i=0;i<nG+1;i++)
	{
		accept[i] = 0.0;
		Nsamp[i] = 0.0;
	}
	double *etaaccept = new double[nD];
	double *etaN = new double[nD];
	for(int d=0;d<nD;d++)
	  {
	    etaaccept[d] = 0.0;
	    etaN[d] = 0.0;
	  }
	double noiseaccept = 0.0;
	double noiseN = 0.0;
	int block = 0;
	double ac,mult;
	Post = 0.0;
	JustLike = 0.0;
	for(int i=0;i<nG;i++)
	{
	  Posts[i] = calcNLN(i);
	  JustLike += Posts[i];
	  for(int j=0;j<4;j++)
	    Posts[i]+=priors[i][j].eval(pars[i][j]);
	  if(Mu0Vals==2)
	    {
	      for(int d=0;d<nD;d++)
		Posts[i]+=Mu0Priors[i].eval(Mu[d][i][0]);
	    }
	  Post += Posts[i];
	}
	for(int d=0;d<nD;d++)
	  {
	    //for(int t=0;t<nT[d]-1;t++)
	    //Post += etapriors[d][t].eval(eta[d][t]);
	    Post += etapriors[d].eval(eta[d]);
	    if(nVarS==1)
	      Post += noiseprior.eval(noiseVar[d]);
	  }

	for(int s=0;s<NSample;s++)
	{
		if(opt>0)
		{
			if(s%opt==0 && s<NSample-1)
			{
				//Look at all the candidates and acceptances
				for(int g=0;g<nG;g++)
				{
					ac = accept[g]/Nsamp[g];
					mult = 1.0;
					if(ac>0.3)
						mult = 1.5;
					else if(ac<0.2)
						mult = 0.5;
					for(int i=0;i<4;i++)
						Cand[g][i] = Cand[g][i]*mult;
					Mu0Cand[g] = Mu0Cand[g]*mult;
					accept[g] = 0.0;
					Nsamp[g] = 0.0;
				}
				for(int d=0;d<nD;d++)
				  {
				    ac = etaaccept[d]/etaN[d];
				    for(int t=0;t<nT[d]-1;t++)
				      {
					if(ac>0.3)
					  etaCand[d][t] = 1.5*etaCand[d][t];
					else if(ac<0.2)
					  etaCand[d][t] = 0.5*etaCand[d][t];
				      }
				    etaaccept[d] = 0.0;
				    etaN[d] = 0.0;
				  }
				ac = noiseaccept/noiseN;
				if(ac>0.3)
				  noiseCand = noiseCand * 1.5;
				else if(ac<0.2)
				  noiseCand = noiseCand * 0.5;
				noiseaccept = 0.0;
				noiseN = 0.0;
			}
		}
		outBlock << block << endl;
		if(s%NSwap==0)
		{
			//Choose a new block
			block = gsl_rng_uniform_int(r,nP);
		}
		if(block<nG)
		{
			accept[block]+=1.0*sampleGene(block);
			Nsamp[block] += 1.0;
		}
		else if(block>=nG && block<nG+nD)
		  {
		    etaaccept[block-nG] += 1.0*sampleEta(block-nG);
		    etaN[block-nG] += 1.0;
		  }
		else if(block==nG+nD)
		  {
		    noiseaccept += 1.0*sampleNoise();
		    noiseN += 1.0;
		  }

		//Write output to file
		postFile << -Post << '\t' << -JustLike;
		for(int d=0;d<nD;d++)
		  { 
		    double temp = 0.0;
		    for(int g=0;g<nG;g++)
		      temp += IndLike[g][d];
		    postFile << '\t' << -temp;
		    for(int t=0;t<nT[d]-1;t++)
		      {
			outEta << eta[d][t] << '\t';
			etaR[d][t] += eta[d][t];
			etaRsq[d][t] += pow(eta[d][t],2.0);
		      }
		    noiseFile << noiseVar[d] << '\t';
		  }
		for(int g=0;g<nG;g++)
		{
			for(int i=0;i<4;i++)
			  {
			    outFile << pars[g][i]<< '\t';
			    R[g][i] += pars[g][i];
			    Rsq[g][i] += pow(pars[g][i],2.0);
			  }
			if(s%1000==0)
			  {
			    for(int d=0;d<nD;d++)
			      {
				for(int t=0;t<nT[d];t++)
				  {
				    MuFile << Mu[d][g][t] << '\t';
				    //MuM[d][g][t]+= Mu[d][g][t];
				    //MuMSq[d][g][t] += pow(Mu[d][g][t],2.0);
				  }
			      }
			  }
		}
		if(s%1000==0)
		  MuFile << endl;
		//Removed max like noise nonsense from here
		outFile << endl;
		noiseFile << endl;
		outEta << endl;
		postFile << endl;
	}
	outFile.close();
	outEta.close();
	outBlock.close();
	postFile.close();
	noiseFile.close();
	MuFile.close();
	/*ofstream MuFile;
	EtaName[0] = 'm';
	MuFile.open(EtaName);
	for(int d=0;d<nD;d++)
	  {
	    for(int g=0;g<nG;g++)
	      {
		for(int t=0;t<nT[d];t++)
			MuFile << MuM[d][g][t]/NSample << '\t';
		MuFile << endl;
		for(int t=0;t<nT[d];t++)
			MuFile << pow(MuMSq[d][g][t]/(NSample-1.0) - pow(MuM[d][g][t]/NSample,2.0),0.5) << '\t';
		MuFile << endl;
	      }
	    MuFile << endl;
	  }
	  MuFile.close();*/
	for(int d=0;d<nD;d++)
	  {
	    for(int g=0;g<nG;g++)
	      {
		delete[] MuM[d][g];
		delete[] MuMSq[d][g];
	      }
	    delete[] MuM[d];
	    delete[] MuMSq[d];
	  }
	delete[] MuM;
	delete[] MuMSq;
	
	/*	cout << endl << "Acceptance Rates: ";
	for(int i=0;i<nG;i++)
	  cout << fixed << endl << "Block: " << i << " " << 100.0*accept[i]/Nsamp[i];
	for(int d=0;d<nD;d++)
	cout << endl << "Eta: " << d << " " << 100.0*etaaccept[d]/etaN[d];*/
	delete[] accept;
	delete[] Nsamp;
	delete[] etaaccept;
	delete[] etaN;
	//Calculate means and variances
	for(int g=0;g<nG;g++)
	{
		for(int i=0;i<4;i++)
		{
			R[g][i] = R[g][i]/(1.0*NSample);
			Rsq[g][i] = Rsq[g][i]/(1.0*NSample) - pow(R[g][i],2.0);
		}
	}
	for(int d=0;d<nD;d++)
	  {
	    for(int t=0;t<nT[d]-1;t++)
	      {
		etaR[d][t] = etaR[d][t]/(1.0*NSample);
		etaRsq[d][t] = etaRsq[d][t]/(1.0*NSample) - pow(etaR[d][t],2.0);
	      }
	  }

}
int MMSampler::sampleNoise()
{
	double *oldNoise = new double[nD];
	for(int d=0;d<nD;d++) oldNoise[d] = noiseVar[d];
	double Npost = 0.0;
	for(int g=0;g<nG;g++)
	{
	  for(int d=0;d<nD;d++)
	    {
	      for(int t=0;t<nT[d];t++)
		{
		  for(int e=0;e<nE[d];e++)
		    Npost += (1.0/(2.0*noiseVar[d]))*pow(log(E[d][g][t][e]) - log(Mu[d][g][t])+0.5*noiseVar[d],2) + log(sqrt(noiseVar[d]));
		}
	    }
	}
	for(int d=0;d<nD;d++)
	  Npost += noiseprior.eval(noiseVar[d]);
	double oldPost = Npost;
	for(int d=0;d<nD;d++)
	  {
	    do{
		noiseVar[d] = oldNoise[d] + gsl_ran_gaussian(r,sqrt(noiseCand));
	    }while(noiseVar[d]<=0.0);
	  }
	Npost = 0.0;
	for(int g=0;g<nG;g++)
	{
	  for(int d=0;d<nD;d++)
	    {
	      for(int t=0;t<nT[d];t++)
		{
		  for(int e=0;e<nE[d];e++)
		    Npost += (1.0/(2.0*noiseVar[d]))*pow(log(E[d][g][t][e]) - log(Mu[d][g][t])+0.5*noiseVar[d],2) + log(sqrt(noiseVar[d]));
		}
	    }
	}
	for(int d=0;d<nD;d++)
	  Npost += noiseprior.eval(noiseVar[d]);
	if(gsl_rng_uniform(r)<=exp(-Npost+oldPost))
	  {
	    Post = 0.0;
	    JustLike = 0.0;
	    for(int g=0;g<nG;g++)
	      {
		Posts[g] = calcNLN(g);
		JustLike += Posts[g];
		for(int i=0;i<4;i++)
		  Posts[g] += priors[g][i].eval(pars[g][i]);
		if(Mu0Vals==2)
		  {
		    for(int d=0;d<nD;d++)
		      Posts[g] += Mu0Priors[g].eval(Mu[d][g][0]);
		  }
		Post += Posts[g];
	      }
	    for(int d=0;d<nD;d++)
	      {
		//for(int t=0;t<nT[d]-1;t++)
		// Post += etapriors[d][t].eval(eta[d][t]);
		Post += etapriors[d].eval(eta[d]);
		if(nVarS == 1)
		  Post += noiseprior.eval(noiseVar[d]);
	      }
	    delete[] oldNoise;
	    return 1;
	  }
	else
	  {
	    for(int d=0;d<nD;d++)
	      noiseVar[d] = oldNoise[d];
	    delete[] oldNoise;
	    return 0;
	}
}
int MMSampler::sampleGene(int g)
{
  //Calculate the posterior of this gene
  for(int d=0;d<nD;d++)
    {
      for(int t=0;t<nT[d];t++)
	oldMu[d][g][t] = Mu[d][g][t];
      OldIndLike[g][d] = IndLike[g][d];
    }
  //Posts[g] should be Uptodate
  for(int i=0;i<4;i++)
    OldPars[i] = pars[g][i];
  double OldPost = Posts[g];
  Post -= Posts[g];
  for(int d=0;d<nD;d++)
    JustLike -= IndLike[g][d];
  double tem;
  //Make the jump
  for(int i=0;i<4;i++)
	{
	  do{
	    tem = pars[g][i] + gsl_ran_gaussian(r,sqrt(Cand[g][i]));
	  }while(tem<0);
	  pars[g][i] = tem;
	}
  if(Mu0Vals==2)
    {
      for(int d=0;d<nD;d++)
	{
	  double oldMuZero = Mu[d][g][0];
	  do{
	    Mu[d][g][0] = oldMuZero + gsl_ran_gaussian(r,sqrt(Mu0Cand[g]));
	  }while(Mu[d][g][0]<0);
	}
    }

  Posts[g] = calcNLN(g);
  for(int i=0;i<4;i++)
    Posts[g] += priors[g][i].eval(pars[g][i]);
  if(Mu0Vals==2)
    {
      for(int d=0;d<nD;d++)
	Posts[g] += Mu0Priors[g].eval(Mu[d][g][0]);
    }
  
  double rat = exp(-Posts[g]+OldPost);
  if(gsl_rng_uniform(r) <= rat)
    {
      Post += Posts[g];
      for(int d=0;d<nD;d++)
	JustLike += IndLike[g][d];
      return 1;
    }
  else
    {
      Posts[g] = OldPost;
      Post += Posts[g];
      for(int i=0;i<4;i++)
	pars[g][i] = OldPars[i];
      for(int d=0;d<nD;d++)
	{
	  IndLike[g][d] = OldIndLike[g][d];
	  JustLike += IndLike[g][d];
	  for(int t=0;t<nT[d];t++)
	    Mu[d][g][t] = oldMu[d][g][t];
	}
      return 0;
    }	
  
}
int MMSampler::sampleEta(int thisd)
{
  //Do a sample of the d'th eta
  //All Posts should be up to date
  double temp;
  double OldPost = Post;
  Post = 0.0;
  for(int g=0;g<nG;g++)
    {
      OldPosts[g] = Posts[g];
      for(int t=0;t<nT[thisd];t++)
	oldMu[thisd][g][t] = Mu[thisd][g][t];
      for(int d=0;d<nD;d++)
	OldIndLike[g][d] = IndLike[g][d];
    }
  for(int t=0;t<nT[thisd]-1;t++)
    {
      oldEta[thisd][t] = eta[thisd][t];
      if(etafix[thisd][t]==0)
	{
	  do{
	    temp = eta[thisd][t] + gsl_ran_gaussian(r,sqrt(etaCand[thisd][t]));
	  }while(temp<0);
	  eta[thisd][t] = temp;
	}
    }
  Post = 0.0;
  JustLike = 0.0;
  for(int g=0;g<nG;g++)
    {
      Posts[g] = calcNLN(g);
      JustLike += Posts[g];
      for(int i=0;i<4;i++)
	Posts[g] += priors[g][i].eval(pars[g][i]);
      if(Mu0Vals==2)
	{
	  for(int d=0;d<nD;d++)
	    Posts[g] += Mu0Priors[g].eval(Mu[d][g][0]);
	}
      Post += Posts[g];
    }
  for(int d=0;d<nD;d++)
    {
      //for(int t=0;t<nT[d]-1;t++)
      //	Post += etapriors[d][t].eval(eta[d][t]);
      Post += etapriors[d].eval(eta[d]);

      if(nVarS==1)
	Post += noiseprior.eval(noiseVar[d]);
    }
	
  if(gsl_rng_uniform(r)<=exp(-Post + OldPost))
    return 1;
  else
    {
      //Swap Back
      for(int t=0;t<nT[thisd]-1;t++)
	eta[thisd][t] = oldEta[thisd][t];
      JustLike = 0.0;
      for(int g=0;g<nG;g++)
	{
	  Posts[g] = OldPosts[g];
	  for(int t=0;t<nT[thisd];t++)
	    Mu[thisd][g][t] = oldMu[thisd][g][t];
	  for(int d=0;d<nD;d++)
	    {
	      IndLike[g][d] = OldIndLike[g][d];
	      JustLike += IndLike[g][d];
	    }
	}
      Post = OldPost;
      return 0;
    }
}
double MMSampler::calcNLN(int g)
{
	//Calculate the negative log of the log normal likelihood
	//Firstly, calculate Mu
	double top;
	double *Mu0V = new double[nD];
	for(int d=0;d<nD;d++)
	  Mu0V[d] = Mu[d][g][0];

	if(Mu0Vals==1)
	  {
	    for(int d=0;d<nD;d++)
	      Mu0V[d] = pars[g][3] + pars[g][0]/(pars[g][1]+1.0);
	  }
	for(int d=0;d<nD;d++)
	  Mu[d][g][0] = 0.0;

	if(act==1)
	{
	  for(int d=0;d<nD;d++)
	    {
	      for(int t=1;t<nT[d];t++)
		Mu[d][g][t] = Mu[d][g][t-1] + (exp(pars[g][2]*T[d][t])-exp(pars[g][2]*T[d][t-1]))*eta[d][t-1]/(eta[d][t-1]+pars[g][1]);//Act
	    }
	}
	else
	{
	  for(int d=0;d<nD;d++)
	    {
	      for(int t=1;t<nT[d];t++)
		Mu[d][g][t] = Mu[d][g][t-1] + (exp(pars[g][2]*T[d][t])-exp(pars[g][2]*T[d][t-1]))*1.0/(eta[d][t-1]+pars[g][1]);//Rep
	    }
	}
	for(int d=0;d<nD;d++)
	  {
	    for(int t=1;t<nT[d];t++)
	      {
		Mu[d][g][t] = Mu[d][g][t] * pars[g][0]*exp(-pars[g][2]*T[d][t]);
		Mu[d][g][t] = Mu[d][g][t] + pars[g][3] + (Mu0V[d]-pars[g][3])*exp(-pars[g][2]*T[d][t]);
	      }
	  }
	//Now for the likelihood
	for(int d=0;d<nD;d++)
	  Mu[d][g][0] = Mu0V[d];
	double L = 0.0;
	for(int d=0;d<nD;d++)
	  {
	    double temp = 0.0;
	    for(int t=0;t<nT[d];t++)
	      {
		for(int e=0;e<nE[d];e++)
		  temp += (1.0/(2.0*noiseVar[d]))*pow(log(E[d][g][t][e])-log(Mu[d][g][t])+0.5*noiseVar[d],2.0);
	      }
	    temp += 0.5*nT[d]*nE[d]*log(noiseVar[d]);
	    IndLike[g][d] = temp;
	    L += temp;
	  }
	delete[] Mu0V;
	return L;
}
void MMSampler::displayPars()
{
	cout << endl;
	for(int g=0;g<nG;g++)
	{
		cout << endl;
		cout << "Gene: " << g;
		for(int i=0;i<4;i++)
			cout << "\t" << pars[g][i];
	}

}

void MMSampler::init2(char *fname)
{
	ifstream inFile;
	inFile.open(fname);
	char *temp = new char[256];
	char c;
	int type,tg;
	double par1,par2;
	while(!inFile.eof()){
		//Read a character
		inFile.get(c);
		switch(c){
		case 't':
			inFile.get(c);//Colon
			for(int d=0;d<nD;d++)
			  {
			    for(int t=0;t<nT[d];t++)
				inFile >> T[d][t];
			  }
			inFile.getline(temp,256,'\n');
			break;
		case 'f':
			inFile.get(c);//Colon
			for(int d=0;d<nD;d++)
			  {
			    for(int t=0;t<nT[d]-1;t++)
				inFile >> etafix[d][t];
			  }
			inFile.getline(temp,256,'\n');
			break;
		case 'e':
			inFile.get(c);//Colon
			for(int d=0;d<nD;d++)
			  {
			    for(int t=0;t<nT[d]-1;t++)
			      {
				if(etafix[d][t]==1)
					inFile >> eta[d][t];
			      }
			  }
			inFile.getline(temp,256,'\n');
			break;
		case 'p':
		  //Eta priors
		  inFile.get(c);//Colon
		  inFile >> type;//Overall Type
		  double V;
		  if(type==1)
		    inFile >> V;
		  for(int d=0;d<nD;d++)
		    {
		      etapriors[d].setType(type);
		      if(type==1)
			etapriors[d].setVar(V);
		    }
		  inFile >> type >> par1 >> par2;//Initial value prior (or overall)
		  for(int d=0;d<nD;d++)
		    {
		      etapriors[d].setInit(type,par1,par2);
		      double *tempeta = new double[nT[d]-1];
		      etapriors[d].sample(r,tempeta);
		      for(int t=0;t<nT[d]-1;t++)
			{
			  if(etafix[d][t] == 0)
			    eta[d][t] = tempeta[t];
			}
		      /*for(int t=0;t<nT[d]-1;t++)
			{
			if(etafix[d][t]==0)
			{
			etapriors[d][t].setType(type,par1,par2);
			eta[d][t] = etapriors[d][t].sample(r);
			}
			}*/
		      delete[] tempeta;
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 'g':
		  inFile >> tg;
		  inFile.get(c);//Colon
		  for(int i=0;i<4;i++)
		    {
		      inFile >> type >> par1 >> par2;
		      priors[tg][i].setType(type,par1,par2);
		      pars[tg][i] = priors[tg][i].sample(r);
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 'x':
		  inFile.get(c);
		  for(int d=0;d<nD;d++)
		    {
		      for(int e=0;e<nE[d];e++)
			{
			  for(int g=0;g<nG;g++)
			    {
			      for(int t=0;t<nT[d];t++)
				inFile >> E[d][g][t][e];
			    }
			}
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 'c':
		  inFile.get(c);
		  for(int i=0;i<4;i++)
		    inFile >> Cand[0][i];
		  for(int g=1;g<nG;g++)
		    {
		      for(int i=0;i<4;i++)
			Cand[g][i] = Cand[0][i];
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 's':
		  inFile.get(c);
		  inFile >> etaCand[0][0];
		  for(int d=0;d<nD;d++)
		    {
		      for(int t=0;t<nT[d]-1;t++)
			etaCand[d][t] = etaCand[0][0];
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 'd':
		  inFile.get(c);
		  inFile >> act;
		  inFile.getline(temp,256,'\n');
		  break;
		case 'n':
		  inFile.get(c);
		  switch(c)
		    {
		    case 'f':
		      inFile.get(c);//Colon
		      for(int d=0;d<nD;d++)
			inFile >> noiseVar[d];
		      nVarS = 0;//Fixed
		      break;
		    case 'p':
		      inFile.get(c);//Colon
		      inFile >> type >> par1 >> par2;
		      noiseprior.setType(type,par1,par2);
		      for(int d=0;d<nD;d++)
			noiseVar[d] = noiseprior.sample(r);
		      nVarS = 1;//Sampled
		      break;
		    case 'l'://DONT EVER USE THIS!
		      inFile.get(c);//Colon
		      for(int d=0;d<nD;d++)
			inFile >> noiseVar[d];
		      nVarS = 2;//Max Like
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		case 'm':
		  inFile.get(c);
		  switch(c)
		    {
		    case 'f':
		      Mu0Vals = 0;//Calculated from mean of data
		      //Calculate it
		      for(int g=0;g<nG;g++)
			{
			  for(int d=0;d<nD;d++)
			    {
			      double temp = 0.0;
			      for(int e=0;e<nE[d];e++)
				temp += E[d][g][0][e];
			      Mu[d][g][0] = temp/(1.0*nE[d]);
			      temp = 0.0;
			    }
			}
		      break;
		    case 'c':
		      Mu0Vals = 1;//Calculated from parameters
		      break;
		    case 'p':
		      Mu0Vals = 2;//Sampled
		      inFile.get(c);//Colon
		      inFile >> type >> par1 >> par2;
		      for(int g=0;g<nG;g++)
			Mu0Priors[g].setType(type,par1,par2);
		      //If Gaussian, set Mean to data mean //This is slightly problematic - use uniform priors
		      if(type==2)
			{
			  for(int g=0;g<nG;g++)
			    {
			      for(int d=0;d<nD;d++)
				{
				  double temp = 0.0;
				  for(int e=0;e<nE[d];e++)
				    temp += E[d][g][0][e];
				  temp = temp / (1.0*nE[d]);
				  Mu0Priors[g].setType(type,temp,par2);
				}
			    }
			}
		      //Initialise
		      for(int g=0;g<nG;g++)
			{
			  for(int d=0;d<nD;d++)
			    {
			      do{
				Mu[d][g][0] = Mu0Priors[g].sample(r);
				Mu[d][g][0] = Mu0Priors[g].sample(r);
			      }while(Mu[d][g][0]<0);
			    }
			}
		    }
		  inFile.getline(temp,256,'\n');
		  break;
		default:
		  inFile.getline(temp,256,'\n');
		}
		
	}

	
	//	displaySettings();
	delete[] temp;
}
void MMSampler::setseed(long SVAL)
{
	gsl_rng_set(r,SVAL);
}

void MMSampler::displaySettings()
{
	cout << endl << endl << "-------------------------------------------------";
	cout << endl << "Sampler Settings...";
	cout << endl << "Number of Datasets: " << nD;
	for(int d=0;d<nD;d++){
	  cout << endl << "Tpoints " << d << ": ";for(int t=0;t<nT[d];t++) cout << T[d][t] << ", ";}
	for(int d=0;d<nD;d++)
	  {
	    cout << endl << "EtaFix1 " << d << ": ";
	    for(int t=0;t<nT[d]-1;t++)
	      {
		if(etafix[d][t]==1)
		  cout << t << "(" << eta[d][t] << "), ";
	      }
	  }

	for(int d=0;d<nD;d++)
	  {
	    cout << endl << "EtaPriors " << d << ": ";
	    etapriors[d].display();
	    /*	    for(int t=0;t<nT[d]-1;t++)
	      {
		if(etafix[d][t]==0)
		  {
		    cout << t;
		    etapriors[d][t].display();
		    cout << ", ";
		  }
		  }*/
	  }
	
	cout << endl << "GENES";
	for(int g=0;g<nG;g++)
	{
		cout << endl << "Gene " << g << " priors: ";
		for(int i=0;i<4;i++)
		{
			cout << i;
			priors[g][i].display();
			cout << ", ";
		}
	}
	cout.precision(3);
	for(int d=0;d<nD;d++)
	  {
	    for(int e=0;e<nE[d];e++)
	      {
		cout << endl << "Expression " << d << ", experiment " << e << "...";
		for(int g=0;g<nG;g++)
		  {
		    cout << endl << "g" << g << ": ";
		    for(int t=0;t<nT[d];t++)
		      cout << fixed << E[d][g][t][e] << '\t';
		  }	
	      }
	  }
	cout << endl << "Candidates for g0: ";for(int i=0;i<4;i++) cout << Cand[0][i] << ", ";
	cout << endl << "Candidate for eta: " << etaCand[0][0];
	cout << endl << "Noise Variance: " << scientific;for(int d=0;d<nD;d++) cout << noiseVar[d] << ", ";
	switch(nVarS)
	{
	case(0): cout << ", fixed";break;
	case(1): cout << ", sampling, ";
		noiseprior.display();break;
	case(2): cout << ", optimising via likelihood";break;
	}
	cout << endl << "Direction: ";
	if(act==1)
		cout << "ACTIVATION";
	else
		cout << "REPRESSION";
	cout << endl << "Mu0 Inference: ";
	switch(Mu0Vals)
	  {
	  case(0):
	    cout << "Using Mean of Data";
	    break;
	  case(1):
	    cout << "Calculating from Parameter Estimates";
	    break;
	  case(2):
	    cout << "Sampling, g0 prior: ";
	    Mu0Priors[0].display();
	    break;
	  }
	/*cout << endl << "Mu0 Priors: ";
	for(int g=0;g<nG;g++) {cout << endl << "g" << g << ": ";Mu0Priors[g].display();} */
	cout << endl << "-------------------------------------------------" << endl << endl;
}

void MMSampler::setstatus(char *fname)
{
  ifstream inFile;
  inFile.open(fname);
  char c;
  char *temp = new char[256];
  while(!inFile.eof()){
    //Read a character
    inFile.get(c);
    switch(c){
    case 'p':
      inFile.get(c);//Colon
      for(int g=0;g<nG;g++)
	{
	  for(int i=0;i<4;i++)
	    inFile >> pars[g][i];
	}
      inFile.getline(temp,256,'\n');
      break;
    case 'e':
      inFile.get(c);//Colon
      for(int d=0;d<nD;d++)
	{
	  for(int t=0;t<nT[d]-1;t++)
	    inFile >> eta[d][t];
	}
      inFile.getline(temp,256,'\n');
      break;
    case 'n':
      inFile.get(c);
      for(int d=0;d<nD;d++)
	inFile >> noiseVar[d];
      inFile.getline(temp,256,'\n');
      break;
    case 'm':
      inFile.get(c);
      for(int d=0;d<nD;d++)
	{
	  for(int g=0;g<nG;g++)
	    inFile >> Mu[d][g][0];
	}
      inFile.getline(temp,256,'\n');
      Mu0Vals = 2;
      break;
    default:
      inFile.getline(temp,256,'\n');
      break;
    }
  }
  delete[] temp;
  inFile.close();
}
void MMSampler::writeE(char *fname)
{
  ofstream Efile;
  Efile.open(fname);
  for(int d=0;d<nD;d++)
    {
      for(int e=0;e<nE[d];e++)
	{
	  for(int g=0;g<nG;g++)
	    {
	      for(int t=0;t<nT[d];t++)
		Efile << E[d][g][t][e] << '\t';
	      Efile << endl;
	    }
	  Efile << endl;
	}
      Efile << endl;
    }
  Efile.close();
}
void MMSampler::sampleData()
{
  double temp;
  for(int g=0;g<nG;g++)
    calcNLN(g);//Updates Mu
  for(int d=0;d<nD;d++)
    {
      for(int g=0;g<nG;g++)
	{
	  for(int t=0;t<nT[d];t++)
	    {
	      for(int e=0;e<nE[d];e++)
		{
		  //Calc expected value
		  temp = log(Mu[d][g][t])-0.5*noiseVar[d];
		  E[d][g][t][e] = gsl_ran_lognormal(r,temp,pow(noiseVar[d],0.5));
		}
	    }
	}
    }
}

MMSampler::~MMSampler()
{
  for(int g=0;g<nG;g++)
    {
      delete[] pars[g];
      delete[] priors[g];
      delete[] Cand[g];
      delete[] IndLike[g];
      delete[] OldIndLike[g];
    }
  delete[] pars;
  delete[] priors;
  delete[] Cand;
  delete[] IndLike;
  delete[] OldIndLike;
  delete[] Mu0Cand;
  delete[] Mu0Priors;
  delete[] OldPosts;
  delete[] OldPars;

  for(int d=0;d<nD;d++)
    {
      for(int g=0;g<nG;g++)
	{
	  for(int t=0;t<nT[d];t++)
	    delete[] E[d][g][t];
	  delete[] E[d][g];
	  delete[] Mu[d][g];
	  delete[] oldMu[d][g];
	}
      delete[] E[d];
      delete[] Mu[d];
      delete[] oldMu[d];
      delete[] oldEta[d];
      delete[] etaCand[d];
      //delete[] etapriors[d];
      delete[] eta[d];
      delete[] T[d];
      delete[] etafix[d];
    }
  delete[] E;
  delete[] etapriors;
  delete[] Mu;
  delete[] oldMu;    
  delete[] oldEta;
  delete[] etaCand;
  delete[] eta;
  delete[] T;
  delete[] etafix;
  delete[] noiseVar;
  delete[] nT;
  delete[] nE;
  delete[] Posts;
  gsl_rng_free(r);
}
