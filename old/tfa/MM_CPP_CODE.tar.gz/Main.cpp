//Main.cpp
#include "MMSampler.h"
#include <iostream.h>

int main(int  argc,char *argv[])
{
	cout << endl << "MCMC for MM kinetics";
	cout << endl << "Simon Rogers, 2006";
	int nS,nB,nBlock,nChain,nG,nD,nRep;

	if(argc<5)
	{
		cout << endl << "Usage: Main.out nG nD options.txt init.txt";
		return 0;
	}


	nG = atoi(argv[1]);
	nD = atoi(argv[2]);
	int *nT = new int[nD];
	int *nE = new int[nD];
	double thresh;
	ifstream inFile;
	inFile.open(argv[3]);
	for(int d=0;d<nD;d++)
	    inFile >> nT[d] >> nE[d];
	inFile >> nB;
	inFile >> nS;
	inFile >> nBlock;
	inFile >> nChain;
	inFile >> thresh;
	inFile >> nRep;



	cout << endl << "Top Parameters: ";
	for(int d=0;d<nD;d++) cout << endl << "Dataset " << d << ", nT:" << nT[d] << ", nE:" << nE[d]; 

	char *name = new char[7];
	char *name2 = new char[8];
	name[1] = '.';
	name[2] = 't';
	name[3] = 'x';
	name[4] = 't';
	name[5] = '\0';
	name2[0] = 'e';
	for(int i=0;i<7;i++)
	  name2[i+1] = name[i];
	
	int finished = 0;//Set to 1 if all pars are below threshold - 1.1
	
	double ***R = new double**[nChain];
	double ***Rsq = new double**[nChain];
	double ***etaR = new double**[nChain];
	double ***etaRsq = new double**[nChain];
	double **B = new double*[nG];
	double **M = new double*[nG];
	double **W = new double*[nG];
	double **RHat = new double*[nG];
	double **Beta = new double*[nD];
	double **Weta = new double*[nD];
	double **Meta = new double*[nD];
	double **RHateta = new double*[nD];
	
	for(int g=0;g<nG;g++)
	{
		B[g] = new double[4];
		M[g] = new double[4];
		W[g] = new double[4];
		RHat[g] = new double[4];
	}
	for(int c=0;c<nChain;c++)
	{
		R[c] = new double*[nG];
		Rsq[c] = new double*[nG];
		etaR[c] = new double*[nD];
		etaRsq[c] = new double*[nD];
		
		for(int d=0;d<nD;d++)
		  {
		    etaR[c][d] = new double[nT[d]-1];
		    etaRsq[c][d] = new double[nT[d]-1];
		  }

		for(int g=0;g<nG;g++)
		{
			R[c][g] = new double[4];
			Rsq[c][g] = new double[4];
		}
	}

	for(int d=0;d<nD;d++)
	  {
	    Beta[d] = new double[nT[d]-1];
	    Weta[d] = new double[nT[d]-1];
	    Meta[d] = new double[nT[d]-1];
	    RHateta[d] = new double[nT[d]-1];
	  }
	
	MMSampler **samp = new MMSampler*[nChain];
	for(int i=0;i<nChain;i++)
	{
		samp[i] = new MMSampler(nG,nD,nT,nE);
		samp[i] -> init2(argv[4]);
		cout << endl << "**********************\nInitial Burn, Chain " << i << "\n************************";
		samp[i] -> sample(nB,nBlock,-1,R[i],Rsq[i],etaR[i],etaRsq[i]);
		samp[i] -> sample(nB,nBlock,50000,R[i],Rsq[i],etaR[i],etaRsq[i]);
		
	}
	int rep = 0;
	do{
	  for(int i=0;i<nChain;i++)
	    {
	      name[0] = char(48+i);
	      name2[1] = char(48+i);
	      cout << endl << "Sampling Chain " << i;
	      samp[i]->sample(nS,nBlock,name,name2,0,R[i],Rsq[i],etaR[i],etaRsq[i]);
	      //samp[i]->sample(nS,nBlock,0,R[i],Rsq[i],etaR[i],etaRsq[i]);
	    }
	  cout << endl << "Computing Stats: ";
	  //Calculate stats
	  finished = 1;
	  if(nChain>1)
	    {
	      for(int g=0;g<nG;g++)
		{
		  for(int i=0;i<4;i++)
		    {
		      M[g][i] = 0.0;
		      for(int c=1;c<nChain;c++)
			M[g][i] += R[c][g][i];
		      M[g][i] = M[g][i]/(1.0*nChain);
		    }
		  for(int i=0;i<4;i++)
		    {
		      B[g][i] = 0.0;
		      for(int j=0;j<nChain;j++)
			B[g][i] += pow(R[j][g][i]-M[g][i],2.0);
		      B[g][i] = (B[g][i]*nS)/(nChain-1.0);
		    }
		  for(int i=0;i<4;i++)
		    {
		      W[g][i] = 0.0;
		      for(int c=0;c<nChain;c++)
			W[g][i] += Rsq[c][g][i];
		      W[g][i] = W[g][i]/(1.0*nChain);
		    }
		  for(int i=0;i<4;i++)
		    {
		      RHat[g][i] = W[g][i]*(nS-1.0)/nS + B[g][i]/(1.0*nS);
		      RHat[g][i] = sqrt(RHat[g][i]/W[g][i]);
		      if(RHat[g][i] >= thresh)
			finished = 0;
		    }
		}
	      cout << fixed << endl << "Kinetic Pars:";
	      for(int g=0;g<nG;g++)
		{
		  cout << endl;
		  for(int i=0;i<4;i++)
		    cout << RHat[g][i] << '\t';
		}
	      //And eta
	      for(int d=0;d<nD;d++)
		{
		  for(int t=0;t<nT[d]-1;t++)
		    {
		      Meta[d][t] = 0.0;
		      for(int c=0;c<nChain;c++)
			Meta[d][t] += etaR[c][d][t];
		      Meta[d][t] = Meta[d][t]/(1.0*nChain);
		      Beta[d][t] = 0.0;
		      for(int c=0;c<nChain;c++)
			Beta[d][t] += pow(etaR[c][d][t]-Meta[d][t],2.0);
		      Beta[d][t] = Beta[d][t]*nS/(nChain-1.0);
		      Weta[d][t] = 0.0;
		      for(int c=0;c<nChain;c++)
			Weta[d][t] += etaRsq[c][d][t];
		      Weta[d][t] = Weta[d][t]/(1.0*nChain);
		      RHateta[d][t] = Weta[d][t]*(nS-1.0)/nS + Beta[d][t]/(1.0*nS);
		      RHateta[d][t] = sqrt(RHateta[d][t]/Weta[d][t]);
		      if(RHateta[d][t] >= thresh)
			finished = 0;
		    }
		}
	      cout << endl << "Eta:";
	      for(int d=0;d<nD;d++)
		{
		  cout << endl;
		  for(int t=0;t<nT[d]-1;t++) cout << RHateta[d][t] << '\t';
		}
	    }
	  rep++;
	  if(finished==0)
	    cout << endl << "Terminating Criteria not met after " << rep << ", re-sampling...";
	}while(finished == 0 && rep<nRep);
	
	/*Free up Memory*/
	for(int i=0;i<nChain;i++)
	  delete samp[i];
	delete[] samp;
	for(int c=0;c<nChain;c++)
	  {
	    for(int d=0;d<nChain;d++)
	      {
		delete[] etaR[c][d];
		delete[] etaRsq[c][d];
	      }
	    delete[] etaR[c];
	    delete[] etaRsq[c];
	    for(int g=0;g<nG;g++)
	      {
		delete[] R[c][g];
		delete[] Rsq[c][g];
	      }
	    delete[] R[c];
	    delete[] Rsq[c];
	  }
	for(int g=0;g<nG;g++)
	  {
	    delete[] B[g];
	    delete[] M[g];
	    delete[] W[g];
	    delete[] RHat[g];
	  }
	for(int d=0;d<nD;d++)
	  {
	    delete[] Beta[d];
	    delete[] Meta[d];
	    delete[] Weta[d];
	    delete[] RHateta[d];
	  }
	delete[] R;
	delete[] Rsq;
	delete[] etaR;
	delete[] etaRsq;
	delete[] name;
	delete[] name2;
	delete[] B;
	delete[] M;
	delete[] W;
	delete[] Beta;
	delete[] Weta;
	delete[] Meta;
	delete[] RHateta;
	delete[] RHat;
	delete[] nT;
	delete[] nE;
}
