#include "etaprior.h"


etaprior::etaprior(int nTin)
{
  nT = nTin;//Note than nT is nT-1....
  InitType = 0;
  par1 = 0;
  par2 = 10;
  Var = 0.1;//Default
  type = 0;//Uniform
}
etaprior::etaprior()
{
  Var = 0.1;
  type = 0;
  InitType = 0;
  par1 = 0;
  par2 = 10;
}
void etaprior::setT(int Tin)
{
  nT = Tin;
}
void etaprior::setType(int typein)
{
  type = typein;
}
void etaprior::setVar(double varin)
{
  Var = varin;
}
void etaprior::setInit(int typein,double p1in,double p2in)
{
  InitType = typein;
  par1 = p1in;
  par2 = p2in;
}
void etaprior::sample(gsl_rng* r, double *etaout)
{
  switch(type){
  case 0:
    for(int t=0;t<nT;t++)
      {
	etaout[t] = par1 + gsl_rng_uniform(r)*(par2-par1);
      }
    break;
  case 1:
    //Sample the initial value
    etaout[0] = par1 + gsl_rng_uniform(r)*(par2-par1);
    for(int t=1;t<nT;t++)
      {
	do{
	  etaout[t] = etaout[t-1] + gsl_ran_gaussian(r,sqrt(Var));
	}while(etaout[t]<0);
      }
    break;
  }
}
void etaprior::display()
{
  switch(type)
    {
    case(0):
      cout << " Uniform";
      break;
    case(1):
      cout << " Markovian Gaussian, Initial, (" << InitType << ",";
      cout << par1 << "," << par2 << "), V: " << Var;
      break;
    }
}
double etaprior::eval(double *etain)
{
  double L=0.0;
  switch(type){
  case 0:
    for(int t=0;t<nT;t++)
      {
	if(etain[t]>=par1 && etain[t]<=par2)
	  L+= -log(1.0/(par2-par1));
	else
	  L+= 1e200;//i.e., very bad
      }
    break;
  case 1:
    if(etain[0]>=par1 && etain[0]<=par2)
      L = -log(1.0/(par2-par1));
    else
      L = 1e200;
    for(int t=1;t<nT;t++)
      {
	L += log(1-gsl_cdf_ugaussian_P(-etain[t-1]/sqrt(Var)));
	L += 0.5*log(2*3.14159*Var) + (1.0/(2*Var))*pow(etain[t]-etain[t-1],2.0);
      }
  break;
  }
  return L;
}
etaprior::~etaprior()
{
  //Nothing to delete
}
