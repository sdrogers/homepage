//etaprior.h
#include<gsl/gsl_rng.h>
#include<gsl/gsl_randist.h>
#include<gsl/gsl_cdf.h>
#include<cmath>
#include<iostream.h>
class etaprior {
 public:
  etaprior();
  etaprior(int nTin);
  ~etaprior();
  void sample(gsl_rng *r,double *etaout);
  double eval(double *etain);
  void setInit(int typein,double p1in,double p2in);
  void setVar(double varin);
  void setT(int Tin);
  void setType(int typein);
  void display();
 private:
  int nT;
  int InitType;
  double par1;
  double par2;
  double Var;
  int type;

};
