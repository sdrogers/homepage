#include "MMSampler.h"
#include <iostream.h>


int main(int argc, char *argv[])
{
  int nG = atoi(argv[1]);
  int nD = atoi(argv[2]);
  int *nT = new int[nD];
  int *nE = new int[nD];
  ifstream setFile;
  setFile.open(argv[3]);
  for(int d=0;d<nD;d++)
    setFile >> nT[d] >> nE[d];
  setFile.close();

  MMSampler *samp;
  samp = new MMSampler(nG,nD,nT,nE);

  samp->init2(argv[4]);
  samp->setstatus(argv[5]);
  samp->sampleData();
  samp->writeE("E.txt");

  delete samp;
  return 1;

}
