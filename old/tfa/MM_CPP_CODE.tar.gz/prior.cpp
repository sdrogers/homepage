//Prior.cpp
#include "prior.h"

prior::prior()
{
	type = 0;//Uniform
	par1 = 0.0;par2 = 100.0;//Default pars
}
prior::prior(int typein,double p1,double p2)
{
	type = typein;
	par1 = p1;
	par2 = p2;
}
void prior::setType(int typein,double p1,double p2)
{
	type = typein;
	par1 = p1;
	par2 = p2;
}
prior::~prior()
{
}
double prior::eval(double val)
{
	switch(type){
	case 0:
	  if(val>=par1 && val<=par2)
	    return -log(1.0/(par2-par1));
	  else
	    return 1e200;//i.e., very bad
	  break;
	case 1:
	  //Eval -log(Gamma prior)
	  return -(par1-1)*log(val) + val/par2;
	  break;	
	case 2:
	  //eval -log(Gaussian)
	  return (1.0/(2.0*par2))*pow(val-par1,2.0);
	}
}
double prior::sample(gsl_rng *r)
{
	switch(type){
		case 0:
			return gsl_rng_uniform(r)*(par2-par1)+par1;
		break;
		case 1:
		//Sampler from gamma
			return gsl_ran_gamma(r,par1,par2);
		break;
		case 2:
			return par1 + gsl_ran_gaussian(r,sqrt(par2));
		break;
	}
}

void prior::display()
{
	cout << "(" << type << ",[" << par1 << "," << par2 << "])";
}
