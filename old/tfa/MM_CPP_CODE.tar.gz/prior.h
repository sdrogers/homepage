//prior.h
#include <cmath>
#include <iostream.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
class prior{
	public:
		prior();
		prior(int typein,double p1,double p2);
		~prior();
		double sample(gsl_rng *r);
		double eval(double value);
		void setType(int typein,double p1,double p2);
		void display();
	private:
		double par1;
		double par2;
		int type;//0 - uniform, 1 - gamma
};
